from __future__ import annotations

import sys
from datetime import date, timedelta
from pathlib import Path
from typing import List

import numpy as np
import pandas as pd
import streamlit as st

# Local imports
ROOT = Path(__file__).resolve().parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.backtest import analyze_mean_reversion
from src.bloomberg import DEFAULT_BBG_FIELDS, bbg_price_history, bbg_reference_data, bbg_yield_history, bql_us_treasury_universe, normalize_tickers
from src.demo_data import make_demo_universe
from src.plotting import pca_explained_variance_figure, residual_bar_figure, reversion_scatter, rv_curve_figure
from src.rv_engine import RVConfig, compute_current_rv

try:
    from streamlit_autorefresh import st_autorefresh
except Exception:  # optional
    st_autorefresh = None

st.set_page_config(
    page_title="Treasury RV Engine",
    page_icon="📈",
    layout="wide",
    initial_sidebar_state="expanded",
)

CUSTOM_CSS = """
<style>
:root {
    --panel: #0F172A;
    --panel2: #111827;
    --border: #1E293B;
    --text: #E5E7EB;
    --muted: #94A3B8;
    --cyan: #38BDF8;
    --green: #22C55E;
    --red: #EF4444;
    --amber: #F59E0B;
}
.block-container { padding-top: 1.2rem; padding-bottom: 2rem; }
[data-testid="stSidebar"] { background: #020617; border-right: 1px solid var(--border); }
.metric-card {
    background: linear-gradient(135deg, #0F172A 0%, #111827 100%);
    border: 1px solid var(--border);
    border-radius: 18px;
    padding: 18px 18px;
    min-height: 120px;
    box-shadow: 0 10px 30px rgba(0,0,0,0.35);
}
.metric-title { color: var(--muted); font-size: 0.84rem; letter-spacing: 0.06em; text-transform: uppercase; }
.metric-value { color: white; font-size: 2.0rem; font-weight: 800; line-height: 1.1; margin-top: 10px; }
.metric-caption { color: var(--muted); margin-top: 8px; font-size: 0.88rem; }
.badge { display: inline-block; padding: 4px 10px; border-radius: 999px; font-weight: 700; font-size: 0.8rem; }
.badge-cheap { background: rgba(34,197,94,0.18); color: #86EFAC; border: 1px solid rgba(34,197,94,0.35); }
.badge-rich { background: rgba(239,68,68,0.18); color: #FCA5A5; border: 1px solid rgba(239,68,68,0.35); }
.badge-neutral { background: rgba(148,163,184,0.18); color: #CBD5E1; border: 1px solid rgba(148,163,184,0.35); }
.hero {
    border: 1px solid var(--border);
    border-radius: 22px;
    padding: 24px;
    background:
      radial-gradient(circle at 10% 20%, rgba(56,189,248,0.22), transparent 26%),
      radial-gradient(circle at 90% 0%, rgba(167,139,250,0.22), transparent 25%),
      linear-gradient(135deg, #020617 0%, #0F172A 100%);
    margin-bottom: 18px;
}
.hero h1 { margin: 0; font-size: 2.2rem; color: white; }
.hero p { color: var(--muted); margin-top: 8px; font-size: 1.02rem; }
hr { border-color: var(--border); }
</style>
"""
st.markdown(CUSTOM_CSS, unsafe_allow_html=True)


def metric_card(title: str, value: str, caption: str = ""):
    st.markdown(
        f"""
        <div class="metric-card">
            <div class="metric-title">{title}</div>
            <div class="metric-value">{value}</div>
            <div class="metric-caption">{caption}</div>
        </div>
        """,
        unsafe_allow_html=True,
    )


@st.cache_data(ttl=55, show_spinner=False)
def load_demo_cached():
    return make_demo_universe(pd.Timestamp.today().normalize())


@st.cache_data(ttl=55, show_spinner=False)
def load_bloomberg_current_cached(tickers: List[str], use_bql: bool):
    if use_bql:
        return bql_us_treasury_universe(max_bonds=100)
    return bbg_reference_data(tickers, DEFAULT_BBG_FIELDS)


@st.cache_data(ttl=3600, show_spinner=False)
def load_bloomberg_history_cached(tickers: List[str], start: date, end: date):
    # Historical mean-reversion should be fast enough for Streamlit. Pull Bloomberg
    # historical YTM for the panel; the live cross-section still solves implied YTM
    # from actual bond prices.
    return bbg_yield_history(tickers, start, end, "YLD_YTM_MID")


def clean_table_for_display(df: pd.DataFrame) -> pd.DataFrame:
    cols = [
        "rv_label", "ticker", "ID_CUSIP", "SECURITY_DES", "maturity_years", "CPN", "PX_MID", "PX_BID", "PX_ASK",
        "ytm_pct", "ns_fit_pct", "pca_fit_pct", "ns_resid_bps", "pca_resid_bps", "ns_z", "pca_z",
        "dv01_100", "bid_ask_width", "AMT_OUTSTANDING",
    ]
    keep = [c for c in cols if c in df.columns]
    out = df[keep].copy()
    rename = {
        "rv_label": "Label",
        "ticker": "Bloomberg Ticker",
        "ID_CUSIP": "CUSIP",
        "SECURITY_DES": "Description",
        "maturity_years": "Years",
        "CPN": "Coupon %",
        "PX_MID": "Mid Px",
        "PX_BID": "Bid Px",
        "PX_ASK": "Ask Px",
        "ytm_pct": "YTM %",
        "ns_fit_pct": "NS Fair %",
        "pca_fit_pct": "PCA Fair %",
        "ns_resid_bps": "NS Resid bp",
        "pca_resid_bps": "PCA Resid bp",
        "ns_z": "NS z",
        "pca_z": "PCA z",
        "dv01_100": "DV01 / $100",
        "bid_ask_width": "Bid/Ask",
        "AMT_OUTSTANDING": "Amount Out",
    }
    return out.rename(columns=rename)


with st.sidebar:
    st.markdown("### Data source")
    data_mode = st.radio("Mode", ["Demo synthetic data", "Bloomberg real data"], index=0)
    use_bql = False
    tickers_text = ""
    if data_mode == "Bloomberg real data":
        use_bql = st.toggle("Use BQL Treasury universe", value=False, help="Optional. If BQL is not configured, paste tickers instead.")
        tickers_text = st.text_area(
            "Bloomberg bond tickers",
            value="T 4.25 05/31/26 Govt\nT 4.625 06/15/27 Govt\nT 4.25 05/15/34 Govt\nT 4.75 02/15/45 Govt",
            height=180,
            help="Paste Treasury securities from Bloomberg/SRCH/GOVT. The app will add 'Govt' if missing.",
            disabled=use_bql,
        )
    st.markdown("### Model settings")
    n_components = st.slider("PCA components", 2, 6, 3)
    z_threshold = st.slider("Agreement z-score threshold", 0.5, 3.0, 1.5, step=0.25)
    horizon = st.slider("Mean-reversion horizon, business days", 1, 30, 5)
    lookback_years = st.slider("Historical lookback, years", 1, 5, 2)
    max_bid_ask = st.number_input("Max bid/ask width filter", min_value=0.01, max_value=5.0, value=0.50, step=0.01)
    min_amt_bln = st.number_input("Min amount outstanding, $bn", min_value=0.0, max_value=100.0, value=0.0, step=1.0)
    auto_refresh = st.toggle("Auto-refresh every 60 seconds", value=False)

if auto_refresh and st_autorefresh is not None:
    st_autorefresh(interval=60_000, key="rv_autorefresh")

st.markdown(
    """
    <div class="hero">
      <h1>Treasury Relative-Value Engine</h1>
      <p>Bloomberg-connected curve monitor: solves bond-implied yields, fits Nelson-Siegel and PCA fair curves, labels rich/cheap only when both models agree, and tests residual mean reversion.</p>
    </div>
    """,
    unsafe_allow_html=True,
)

cfg = RVConfig(
    n_pca_components=n_components,
    z_threshold=z_threshold,
    max_bid_ask=max_bid_ask,
    min_amount_outstanding=min_amt_bln * 1e9,
)

try:
    if data_mode == "Demo synthetic data":
        current_raw, price_hist = load_demo_cached()
        data_source = "Demo synthetic Treasury-like data"
        diagnostics_source = ["Synthetic price panel generated locally; Bloomberg not used."]
    else:
        tickers = normalize_tickers(tickers_text) if not use_bql else []
        if not use_bql and len(tickers) < 4:
            st.warning("Paste at least four Bloomberg Treasury bond tickers, or switch back to demo mode.")
            st.stop()
        current_result = load_bloomberg_current_cached(tickers, use_bql)
        current_raw = current_result.data
        data_source = current_result.source
        diagnostics_source = current_result.diagnostics
        tickers_for_hist = current_raw["ticker"].astype(str).tolist() if "ticker" in current_raw.columns else tickers
        start = date.today() - timedelta(days=int(365.25 * lookback_years))
        end = date.today()
        try:
            hist_result = load_bloomberg_history_cached(tickers_for_hist, start, end)
            price_hist = hist_result.data
            diagnostics_source += hist_result.diagnostics
        except Exception as exc:
            price_hist = pd.DataFrame()
            diagnostics_source.append(f"Historical Bloomberg pull failed: {exc}")

    rv_df, diag = compute_current_rv(current_raw, price_hist, cfg)
    yhist = diag.get("yield_history", pd.DataFrame())
    rev = analyze_mean_reversion(
        yhist,
        diag.get("residual_hist_ns", pd.DataFrame()),
        diag.get("residual_hist_pca", pd.DataFrame()),
        horizon_days=horizon,
        z_threshold=z_threshold,
    )
except Exception as exc:
    st.error(f"RV engine failed: {exc}")
    st.info("Use demo mode first to verify the app, then confirm Bloomberg tickers/fields/entitlements on the Terminal machine.")
    st.stop()

cheap_n = int((rv_df["rv_label"] == "CHEAP").sum())
rich_n = int((rv_df["rv_label"] == "RICH").sum())
disagree_n = int((rv_df["rv_label"] == "DISAGREE").sum())
neutral_n = int((rv_df["rv_label"] == "NEUTRAL").sum())

c1, c2, c3, c4 = st.columns(4)
with c1:
    metric_card("Agreement Cheap", str(cheap_n), "Both NS and PCA say yield is high vs fair")
with c2:
    metric_card("Agreement Rich", str(rich_n), "Both NS and PCA say yield is low vs fair")
with c3:
    ev = diag.get("pca_explained_variance_ratio")
    ev_txt = f"{np.sum(ev[:min(3, len(ev))])*100:.1f}%" if ev is not None else "N/A"
    metric_card("Top PCA Variance", ev_txt, "Variance explained by selected PCs")
with c4:
    corr_txt = "N/A" if pd.isna(rev.correlation) else f"{rev.correlation:.2f}"
    metric_card("Reversion Corr", corr_txt, f"{horizon}d signal strength vs convergence")

tab_dash, tab_table, tab_reversion, tab_math, tab_diag = st.tabs([
    "Dashboard", "Rich/Cheap Table", "Mean Reversion", "Math", "Diagnostics"
])

with tab_dash:
    st.plotly_chart(rv_curve_figure(rv_df), use_container_width=True)
    col_a, col_b = st.columns(2)
    with col_a:
        st.plotly_chart(residual_bar_figure(rv_df, "ns"), use_container_width=True)
    with col_b:
        st.plotly_chart(residual_bar_figure(rv_df, "pca"), use_container_width=True)
    col_c, col_d = st.columns([1, 1])
    with col_c:
        st.markdown("#### Strongest agreement signals")
        strong = rv_df[rv_df["rv_label"].isin(["CHEAP", "RICH"])]
        strong = strong.sort_values("agreement_score", ascending=False).head(10)
        st.dataframe(clean_table_for_display(strong), use_container_width=True, hide_index=True)
    with col_d:
        st.plotly_chart(pca_explained_variance_figure(diag.get("pca_explained_variance_ratio")), use_container_width=True)

with tab_table:
    st.markdown("#### Full live cross-section")
    display = clean_table_for_display(rv_df)
    st.dataframe(
        display,
        use_container_width=True,
        hide_index=True,
        column_config={
            "YTM %": st.column_config.NumberColumn(format="%.3f"),
            "NS Fair %": st.column_config.NumberColumn(format="%.3f"),
            "PCA Fair %": st.column_config.NumberColumn(format="%.3f"),
            "NS Resid bp": st.column_config.NumberColumn(format="%.2f"),
            "PCA Resid bp": st.column_config.NumberColumn(format="%.2f"),
            "NS z": st.column_config.NumberColumn(format="%.2f"),
            "PCA z": st.column_config.NumberColumn(format="%.2f"),
            "DV01 / $100": st.column_config.NumberColumn(format="%.5f"),
        },
    )
    csv = display.to_csv(index=False).encode("utf-8")
    st.download_button("Download current RV table", csv, file_name="treasury_rv_table.csv", mime="text/csv")

with tab_reversion:
    st.markdown("#### Historical label test")
    st.write(
        "Positive convergence means a rich/cheap residual moved back toward fair value over the selected horizon. "
        "This is a signal-quality check, not a PnL backtest."
    )
    m1, m2, m3 = st.columns(3)
    with m1:
        metric_card("Historical Signals", str(len(rev.panel)), "Non-neutral agreement labels")
    with m2:
        hit_txt = "N/A" if pd.isna(rev.hit_rate) else f"{rev.hit_rate*100:.1f}%"
        metric_card("Convergence Hit Rate", hit_txt, "Residual moved in expected direction")
    with m3:
        corr_txt = "N/A" if pd.isna(rev.correlation) else f"{rev.correlation:.3f}"
        metric_card("Correlation", corr_txt, "Signal strength vs convergence")
    if rev.summary is not None and not rev.summary.empty:
        st.dataframe(rev.summary, use_container_width=True, hide_index=True)
    st.plotly_chart(reversion_scatter(rev.panel), use_container_width=True)
    with st.expander("Pooled time-series regression / AR diagnostics"):
        st.code(rev.pooled_model_text)

with tab_math:
    st.markdown("## Mathematical specification")
    st.markdown("### 1. Dirty price and solved bond-implied yield")
    st.latex(r"P_i^{dirty}=P_i^{clean}+AI_i")
    st.latex(r"P_i^{dirty}=\sum_{k=1}^{N_i}\frac{CF_{i,k}}{(1+y_i/m)^{m t_{i,k}}}")
    st.markdown(
        "The app solves this equation numerically for each bond's bond-equivalent yield "
        r"$y_i$. For US Treasuries, $m=2$ under semiannual compounding."
    )

    st.markdown("### 2. Nelson-Siegel fair curve")
    st.latex(r"y(\tau)=\beta_0+\beta_1\left(\frac{1-e^{-\tau/\lambda}}{\tau/\lambda}\right)+\beta_2\left(\frac{1-e^{-\tau/\lambda}}{\tau/\lambda}-e^{-\tau/\lambda}\right)")
    st.latex(r"\widehat{\theta}=\arg\min_{\beta_0,\beta_1,\beta_2,\lambda}\sum_i w_i\left(y_i-y(\tau_i;\theta)\right)^2")
    st.markdown(
        "Weights can incorporate liquidity proxies such as bid/ask width and amount outstanding, "
        "so very stale or wide-market bonds do not dominate the curve."
    )

    st.markdown("### 3. PCA fair-yield reconstruction")
    st.latex(r"X_t = \frac{Y_t-\mu}{\sigma}")
    st.latex(r"X_t \approx \sum_{j=1}^{K} s_{t,j} v_j")
    st.latex(r"\widehat{Y}^{PCA}_t=\mu+\sigma\odot\left(\sum_{j=1}^{K} s_{t,j} v_j\right)")
    st.markdown(
        "The PCA model learns the historical low-dimensional yield manifold. Current yields are projected onto "
        "the top principal components and reconstructed. The difference between observed and reconstructed yield "
        "is the PCA idiosyncratic residual."
    )

    st.markdown("### 4. Residuals, z-scores, and agreement label")
    st.latex(r"r^{NS}_{i,t}=10^4\left(y_{i,t}-\widehat{y}^{NS}_{i,t}\right),\qquad r^{PCA}_{i,t}=10^4\left(y_{i,t}-\widehat{y}^{PCA}_{i,t}\right)")
    st.latex(r"z^M_{i,t}=\frac{r^M_{i,t}-\mu^M_i}{\sigma^M_i},\qquad M\in\{NS,PCA\}")
    st.latex(r"\text{Cheap}_{i,t}=\mathbf{1}\{z^{NS}_{i,t}\ge z^*,\ z^{PCA}_{i,t}\ge z^*\}")
    st.latex(r"\text{Rich}_{i,t}=\mathbf{1}\{z^{NS}_{i,t}\le -z^*,\ z^{PCA}_{i,t}\le -z^*\}")
    st.markdown(
        "Yield above fair value means the bond is cheap on yield; yield below fair value means it is rich. "
        "The dashboard only gives the strong label when both models agree."
    )

    st.markdown("### 5. Mean-reversion test")
    st.latex(r"s_{i,t}=\begin{cases}+1,&\text{cheap}\\-1,&\text{rich}\\0,&\text{otherwise}\end{cases}")
    st.latex(r"C_{i,t,h}=s_{i,t}\left(r_{i,t}-r_{i,t+h}\right)")
    st.markdown("Positive $C_{i,t,h}$ means the residual moved toward zero in the direction implied by the label.")
    st.latex(r"\Delta r_{i,t,h}=\alpha+\beta r_{i,t}+\varepsilon_{i,t+h}")
    st.markdown("A negative $\beta$ is evidence of mean reversion in residuals. The app also reports AR(1) half-life estimates.")

with tab_diag:
    st.markdown("#### Data and model diagnostics")
    st.write(f"**Data source:** {data_source}")
    for line in diagnostics_source:
        st.write(f"- {line}")
    if "pca_warning" in diag:
        st.warning(diag["pca_warning"])
    if "ns_history_warning" in diag:
        st.warning(diag["ns_history_warning"])
    st.write(f"Current bonds after filters: {diag.get('n_current_after_filters')}")
    ns_fit = diag.get("ns_fit")
    if ns_fit is not None:
        st.json({
            "beta0": getattr(ns_fit, "beta0", None),
            "beta1": getattr(ns_fit, "beta1", None),
            "beta2": getattr(ns_fit, "beta2", None),
            "lambda": getattr(ns_fit, "lambda_", None),
            "rmse_decimal_yield": getattr(ns_fit, "rmse", None),
            "success": getattr(ns_fit, "success", None),
        })
    comps = diag.get("pca_components")
    if isinstance(comps, pd.DataFrame) and not comps.empty:
        st.markdown("#### PCA loadings")
        st.dataframe(comps, use_container_width=True)
