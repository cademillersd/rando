from __future__ import annotations

from datetime import date
from typing import Tuple

import numpy as np
import pandas as pd

from .fixed_income import price_from_yield, years_to_maturity


def ns_curve(tau, b0=0.042, b1=-0.008, b2=0.010, lam=2.2):
    tau = np.asarray(tau, dtype=float)
    x = np.maximum(tau / lam, 1e-9)
    l1 = (1 - np.exp(-x)) / x
    l2 = l1 - np.exp(-x)
    return b0 + b1 * l1 + b2 * l2


def make_demo_universe(as_of: pd.Timestamp | None = None, n_bonds: int = 34, seed: int = 7) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """Synthetic Treasury-like universe with mean-reverting RV residuals.

    Returns current cross-section and historical decimal-yield panel.
    """
    rng = np.random.default_rng(seed)
    as_of = pd.Timestamp(as_of or pd.Timestamp.today()).normalize()
    maturities_years = np.array(
        [0.5, 0.75, 1, 1.25, 1.5, 2, 2.5, 3, 3.5, 4, 4.5, 5, 5.5, 6, 6.5, 7, 7.5, 8, 9, 10,
         11, 12, 13, 15, 17, 20, 22, 25, 27, 30]
    )
    if n_bonds < len(maturities_years):
        maturities_years = np.sort(rng.choice(maturities_years, n_bonds, replace=False))
    coupons = np.round((ns_curve(maturities_years) + rng.normal(0, 0.0025, len(maturities_years))) * 8) / 8 * 100
    coupons = np.clip(coupons, 0.125, 7.0)
    tickers = [f"T {c:.3f} {((as_of + pd.DateOffset(days=int(y*365.25))).strftime('%m/%d/%y'))} Govt" for c, y in zip(coupons, maturities_years)]
    maturities = [as_of + pd.DateOffset(days=int(y * 365.25)) for y in maturities_years]

    dates = pd.bdate_range(as_of - pd.DateOffset(years=2), as_of)
    nT, nN = len(dates), len(tickers)
    base_taus = np.zeros((nT, nN))
    residuals = np.zeros((nT, nN))

    # Level/slope/curvature stochastic factors plus security-specific AR residuals.
    level = 0.041 + np.cumsum(rng.normal(0, 0.00035, nT))
    slope = -0.010 + np.cumsum(rng.normal(0, 0.00012, nT))
    curv = 0.008 + np.cumsum(rng.normal(0, 0.00016, nT))
    phi = 0.92
    resid_vol = 0.0009 * (1 + 0.3 * rng.random(nN))
    shocks = rng.normal(0, resid_vol, size=(nT, nN))
    for t in range(1, nT):
        residuals[t] = phi * residuals[t - 1] + shocks[t]
    # Make a few current bonds visibly rich/cheap.
    residuals[-1, [7, 15, 23]] += np.array([0.0025, -0.0030, 0.0022])[: min(3, nN)]

    yield_hist = pd.DataFrame(index=dates, columns=tickers, dtype=float)
    for ti, dt in enumerate(dates):
        taus = np.array([years_to_maturity(dt, m) for m in maturities])
        base_taus[ti] = taus
        fair_y = ns_curve(taus, level[ti], slope[ti], curv[ti], 2.2)
        yield_hist.iloc[ti] = fair_y + residuals[ti]
    yield_hist.attrs["kind"] = "yield_decimal"

    # Only current prices are needed for the live implied-yield solve. Keeping the
    # historical panel as yields makes the app interactive instead of solving tens
    # of thousands of bond IRRs on each refresh.
    current_yields = yield_hist.iloc[-1]
    current_px = pd.Series(
        [price_from_yield(current_yields.iloc[j], coupons[j], maturities[j], as_of) for j in range(nN)],
        index=tickers,
    )
    rows = []
    for i, ticker in enumerate(tickers):
        bid_ask = 0.015 + 0.03 * rng.random()
        rows.append(
            {
                "ticker": ticker,
                "PX_BID": current_px.iloc[i] - bid_ask / 2,
                "PX_ASK": current_px.iloc[i] + bid_ask / 2,
                "PX_LAST": current_px.iloc[i],
                "PX_MID": current_px.iloc[i],
                "ACCRUED_INTEREST": 0.0,
                "CPN": coupons[i],
                "MATURITY": maturities[i],
                "ISSUE_DT": as_of - pd.DateOffset(years=2),
                "ID_CUSIP": f"DEMO{i:05d}",
                "SECURITY_DES": f"Demo UST {coupons[i]:.3f}% {maturities[i].date()}",
                "CRNCY": "USD",
                "AMT_OUTSTANDING": float(rng.uniform(20, 65) * 1e9),
                "as_of": as_of,
            }
        )
    return pd.DataFrame(rows), yield_hist
