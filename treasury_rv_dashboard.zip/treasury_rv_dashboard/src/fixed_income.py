from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime
from typing import Iterable, List, Optional

import numpy as np
import pandas as pd
from dateutil.relativedelta import relativedelta
from scipy.optimize import brentq


@dataclass(frozen=True)
class BondStatic:
    ticker: str
    coupon: float  # annual coupon rate in percent, e.g. 4.25
    maturity: pd.Timestamp
    issue_date: Optional[pd.Timestamp] = None
    cusip: Optional[str] = None
    description: Optional[str] = None
    amount_outstanding: Optional[float] = None
    currency: str = "USD"


def _to_timestamp(x) -> pd.Timestamp:
    if pd.isna(x):
        return pd.NaT
    return pd.Timestamp(x).normalize()


def years_to_maturity(as_of: pd.Timestamp, maturity: pd.Timestamp) -> float:
    as_of = _to_timestamp(as_of)
    maturity = _to_timestamp(maturity)
    return max((maturity - as_of).days / 365.25, 0.0)


def semiannual_cashflow_dates(as_of: pd.Timestamp, maturity: pd.Timestamp) -> List[pd.Timestamp]:
    """Approximate US Treasury cashflow schedule using semiannual backward stepping.

    Bloomberg/YAS has more exact day-count and schedule logic. This approximation is
    intentionally transparent and good enough for an RV dashboard prototype. For
    production, replace this with QuantLib schedule/cashflows or Bloomberg YAS outputs.
    """
    as_of = _to_timestamp(as_of)
    maturity = _to_timestamp(maturity)
    if pd.isna(maturity) or maturity <= as_of:
        return []

    dates = []
    d = maturity
    while d > as_of:
        dates.append(d)
        d = d - relativedelta(months=6)
    return sorted(dates)


def cashflows_per_100(
    coupon_pct: float,
    maturity: pd.Timestamp,
    as_of: pd.Timestamp,
    face: float = 100.0,
    frequency: int = 2,
) -> pd.DataFrame:
    dates = semiannual_cashflow_dates(as_of, maturity)
    if not dates:
        return pd.DataFrame(columns=["date", "t", "cf"])
    coupon_cash = face * (float(coupon_pct) / 100.0) / frequency
    rows = []
    for d in dates:
        cf = coupon_cash
        if d == max(dates):
            cf += face
        rows.append({"date": d, "t": years_to_maturity(as_of, d), "cf": cf})
    return pd.DataFrame(rows)


def price_from_yield(
    ytm_decimal: float,
    coupon_pct: float,
    maturity: pd.Timestamp,
    as_of: pd.Timestamp,
    face: float = 100.0,
    frequency: int = 2,
) -> float:
    cfs = cashflows_per_100(coupon_pct, maturity, as_of, face=face, frequency=frequency)
    if cfs.empty:
        return np.nan
    n = np.ceil(cfs["t"].to_numpy() * frequency).astype(float)
    discount = (1.0 + ytm_decimal / frequency) ** n
    return float(np.sum(cfs["cf"].to_numpy() / discount))


def yield_from_dirty_price(
    dirty_price: float,
    coupon_pct: float,
    maturity: pd.Timestamp,
    as_of: pd.Timestamp,
    frequency: int = 2,
) -> float:
    """Solve annualized bond-equivalent YTM from dirty price per $100 face.

    Returns decimal yield, e.g. 0.0425 for 4.25%.
    """
    if dirty_price is None or pd.isna(dirty_price) or dirty_price <= 0:
        return np.nan
    if pd.isna(maturity) or _to_timestamp(maturity) <= _to_timestamp(as_of):
        return np.nan

    def objective(y):
        return price_from_yield(y, coupon_pct, maturity, as_of, frequency=frequency) - dirty_price

    # Treasury yields almost surely live inside this bracket. Keeping a wide bracket
    # makes the solver robust to synthetic/demo or stressed historical data.
    for lo, hi in [(-0.10, 0.25), (-0.50, 1.00)]:
        try:
            return float(brentq(objective, lo, hi, maxiter=200, xtol=1e-12))
        except ValueError:
            continue
    return np.nan


def macaulay_duration(
    ytm_decimal: float,
    coupon_pct: float,
    maturity: pd.Timestamp,
    as_of: pd.Timestamp,
    frequency: int = 2,
) -> float:
    cfs = cashflows_per_100(coupon_pct, maturity, as_of, frequency=frequency)
    if cfs.empty or pd.isna(ytm_decimal):
        return np.nan
    n = np.ceil(cfs["t"].to_numpy() * frequency).astype(float)
    pv = cfs["cf"].to_numpy() / (1.0 + ytm_decimal / frequency) ** n
    price = np.sum(pv)
    if price <= 0:
        return np.nan
    return float(np.sum(cfs["t"].to_numpy() * pv) / price)


def modified_duration(
    ytm_decimal: float,
    coupon_pct: float,
    maturity: pd.Timestamp,
    as_of: pd.Timestamp,
    frequency: int = 2,
) -> float:
    mac = macaulay_duration(ytm_decimal, coupon_pct, maturity, as_of, frequency=frequency)
    if pd.isna(mac):
        return np.nan
    return float(mac / (1.0 + ytm_decimal / frequency))


def dv01_per_100(
    ytm_decimal: float,
    coupon_pct: float,
    maturity: pd.Timestamp,
    as_of: pd.Timestamp,
    frequency: int = 2,
) -> float:
    """Dollar value of a 1bp yield move per $100 face, positive number."""
    p = price_from_yield(ytm_decimal, coupon_pct, maturity, as_of, frequency=frequency)
    md = modified_duration(ytm_decimal, coupon_pct, maturity, as_of, frequency=frequency)
    if pd.isna(p) or pd.isna(md):
        return np.nan
    return float(p * md * 1e-4)


def infer_dirty_price(row: pd.Series) -> float:
    """Choose dirty price using Bloomberg-like fields.

    Bloomberg clean prices are quoted per 100 face. Dirty price = clean + accrued.
    If PX_MID is absent, use bid/ask midpoint, else PX_LAST. Accrued interest is also
    normally per 100 face for US Treasuries.
    """
    clean_candidates = ["PX_MID", "mid", "PX_LAST", "last_price"]
    clean = np.nan
    for col in clean_candidates:
        if col in row and pd.notna(row[col]):
            clean = float(row[col])
            break
    if pd.isna(clean):
        bid = row.get("PX_BID", np.nan)
        ask = row.get("PX_ASK", np.nan)
        if pd.notna(bid) and pd.notna(ask):
            clean = 0.5 * (float(bid) + float(ask))
    accrued = row.get("ACCRUED_INTEREST", row.get("accrued_interest", 0.0))
    accrued = 0.0 if pd.isna(accrued) else float(accrued)
    if pd.isna(clean):
        return np.nan
    return clean + accrued


def enrich_yields_from_prices(df: pd.DataFrame, as_of_col: str = "as_of") -> pd.DataFrame:
    """Add dirty price, solved YTM, maturity years, duration and DV01 columns."""
    out = df.copy()
    if as_of_col not in out.columns:
        out[as_of_col] = pd.Timestamp.today().normalize()
    out["as_of"] = pd.to_datetime(out[as_of_col]).dt.normalize()
    out["MATURITY"] = pd.to_datetime(out["MATURITY"]).dt.normalize()
    out["dirty_price"] = out.apply(infer_dirty_price, axis=1)
    out["ytm"] = out.apply(
        lambda r: yield_from_dirty_price(r["dirty_price"], r["CPN"], r["MATURITY"], r["as_of"]), axis=1
    )
    out["maturity_years"] = out.apply(lambda r: years_to_maturity(r["as_of"], r["MATURITY"]), axis=1)
    out["mod_duration"] = out.apply(
        lambda r: modified_duration(r["ytm"], r["CPN"], r["MATURITY"], r["as_of"]), axis=1
    )
    out["dv01_100"] = out.apply(
        lambda r: dv01_per_100(r["ytm"], r["CPN"], r["MATURITY"], r["as_of"]), axis=1
    )
    return out


def build_yield_history_from_prices(
    price_history: pd.DataFrame,
    static_df: pd.DataFrame,
    accrued_history: Optional[pd.DataFrame] = None,
) -> pd.DataFrame:
    """Convert historical clean prices into solved historical yields.

    price_history: index=date, columns=ticker, clean price per 100.
    static_df: columns ticker, CPN, MATURITY.
    accrued_history: optional matching frame of accrued interest per 100.
    """
    static = static_df.set_index("ticker") if "ticker" in static_df.columns else static_df.set_index("security")
    rows = []
    for dt, px_row in price_history.iterrows():
        as_of = pd.Timestamp(dt).normalize()
        for ticker, clean_px in px_row.items():
            if ticker not in static.index or pd.isna(clean_px):
                continue
            coupon = static.loc[ticker, "CPN"]
            mat = pd.Timestamp(static.loc[ticker, "MATURITY"]).normalize()
            accrued = 0.0
            if accrued_history is not None and ticker in accrued_history.columns and dt in accrued_history.index:
                accrued = accrued_history.loc[dt, ticker]
                accrued = 0.0 if pd.isna(accrued) else float(accrued)
            y = yield_from_dirty_price(float(clean_px) + accrued, coupon, mat, as_of)
            rows.append({"date": as_of, "ticker": ticker, "ytm": y, "maturity_years": years_to_maturity(as_of, mat)})
    long = pd.DataFrame(rows)
    if long.empty:
        return pd.DataFrame()
    return long.pivot(index="date", columns="ticker", values="ytm").sort_index()
