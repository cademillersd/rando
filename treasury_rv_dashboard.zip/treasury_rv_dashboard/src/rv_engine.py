from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Optional, Tuple

import numpy as np
import pandas as pd

from .curve_models import PCACurveModel, fit_nelson_siegel, historical_residual_zscores, robust_zscore
from .fixed_income import build_yield_history_from_prices, enrich_yields_from_prices


@dataclass
class RVConfig:
    n_pca_components: int = 3
    z_threshold: float = 1.5
    use_dv01_weights_for_ns: bool = True
    min_maturity_years: float = 0.25
    max_bid_ask: float = 0.50
    min_amount_outstanding: float = 0.0


def liquidity_weight(df: pd.DataFrame) -> pd.Series:
    """Simple weight proxy: tighter bid/ask and larger amount outstanding get more influence."""
    ba = (pd.to_numeric(df.get("PX_ASK", np.nan), errors="coerce") - pd.to_numeric(df.get("PX_BID", np.nan), errors="coerce")).abs()
    ba = ba.replace(0.0, np.nan)
    amount = pd.to_numeric(df.get("AMT_OUTSTANDING", np.nan), errors="coerce")
    amount_score = np.log1p(amount.fillna(amount.median() if amount.notna().any() else 1.0))
    ba_score = 1.0 / ba.fillna(ba.median() if ba.notna().any() else 0.05)
    w = amount_score * ba_score
    w = w.replace([np.inf, -np.inf], np.nan).fillna(1.0)
    return w / w.mean()


def apply_basic_filters(df: pd.DataFrame, cfg: RVConfig) -> pd.DataFrame:
    out = df.copy()
    out["bid_ask_width"] = (pd.to_numeric(out.get("PX_ASK", np.nan), errors="coerce") - pd.to_numeric(out.get("PX_BID", np.nan), errors="coerce")).abs()
    mask = out["ytm"].notna() & out["maturity_years"].between(cfg.min_maturity_years, 40.0)
    if cfg.max_bid_ask is not None and "bid_ask_width" in out:
        mask &= out["bid_ask_width"].isna() | (out["bid_ask_width"] <= cfg.max_bid_ask)
    if cfg.min_amount_outstanding > 0 and "AMT_OUTSTANDING" in out:
        amt = pd.to_numeric(out["AMT_OUTSTANDING"], errors="coerce")
        mask &= amt.isna() | (amt >= cfg.min_amount_outstanding)
    return out.loc[mask].copy().sort_values("maturity_years")


def compute_current_rv(
    current_raw: pd.DataFrame,
    price_history: Optional[pd.DataFrame] = None,
    cfg: Optional[RVConfig] = None,
) -> Tuple[pd.DataFrame, Dict[str, object]]:
    """Main current RV calculation.

    Returns current dataframe with solved yields, NS fair yields, PCA fair yields,
    residuals, z-scores and agreement labels.
    """
    cfg = cfg or RVConfig()
    cur = enrich_yields_from_prices(current_raw)
    cur = apply_basic_filters(cur, cfg)
    diagnostics: Dict[str, object] = {"n_current_after_filters": len(cur)}
    if len(cur) < max(6, cfg.n_pca_components + 2):
        raise ValueError("Not enough valid bonds after filters to fit curves.")

    weights = liquidity_weight(cur) if cfg.use_dv01_weights_for_ns else pd.Series(1.0, index=cur.index)
    ns = fit_nelson_siegel(cur["maturity_years"], cur["ytm"], weights=weights)
    cur["ns_fit"] = ns.predict(cur["maturity_years"])
    cur["ns_resid_bps"] = (cur["ytm"] - cur["ns_fit"]) * 1e4
    diagnostics["ns_fit"] = ns

    pca_model = None
    yhist = pd.DataFrame()
    pca_current_fit = pd.Series(np.nan, index=cur["ticker"])
    residual_hist_ns = pd.DataFrame()
    residual_hist_pca = pd.DataFrame()

    if price_history is not None and not price_history.empty:
        try:
            static = cur[["ticker", "CPN", "MATURITY"]].copy()
            # Keep historical panel aligned to current securities.
            hist = price_history.reindex(columns=cur["ticker"].tolist()).dropna(axis=1, how="all")
            # For interactive performance, prefer a pre-solved historical yield panel.
            # Bloomberg YLD_YTM_MID history can be passed as decimal yields with attrs['kind']='yield_decimal'.
            # If clean prices are passed, we solve yields security/date by date.
            if getattr(price_history, "attrs", {}).get("kind") == "yield_decimal":
                yhist = hist.copy().astype(float)
            else:
                yhist = build_yield_history_from_prices(hist, static)
            yhist = yhist.reindex(columns=cur["ticker"].tolist()).ffill().bfill().dropna(axis=0, how="any")
            if len(yhist) >= max(20, cfg.n_pca_components + 2) and yhist.shape[1] >= cfg.n_pca_components + 1:
                pca_model = PCACurveModel(n_components=cfg.n_pca_components, standardize=True).fit(yhist)
                current_series = cur.set_index("ticker")["ytm"]
                pca_current_fit = pca_model.reconstruct(current_series)
                cur["pca_fit"] = cur["ticker"].map(pca_current_fit)
                diagnostics["pca_explained_variance_ratio"] = pca_model.explained_variance_ratio_
                diagnostics["pca_components"] = pca_model.component_table()

                # Historical PCA residuals for security-wise z-scoring.
                hist_fit_rows = []
                for dt, row in yhist.iterrows():
                    fit = pca_model.reconstruct(row)
                    hist_fit_rows.append(fit.rename(dt))
                hist_fit = pd.DataFrame(hist_fit_rows)
                residual_hist_pca = (yhist - hist_fit) * 1e4
        except Exception as exc:
            diagnostics["pca_warning"] = str(exc)

        # Historical NS residuals, fit cross-section date by date.
        try:
            mats = cur.set_index("ticker")["MATURITY"]
            ns_rows = []
            for dt, row in yhist.iterrows():
                tmp = pd.DataFrame({"ticker": row.index, "ytm": row.values})
                tmp["maturity_years"] = tmp["ticker"].map(lambda t: max((pd.Timestamp(mats[t]) - pd.Timestamp(dt)).days / 365.25, 0.0))
                f = fit_nelson_siegel(tmp["maturity_years"], tmp["ytm"])
                fit_vals = pd.Series(f.predict(tmp["maturity_years"]), index=tmp["ticker"].values)
                ns_rows.append(((row - fit_vals) * 1e4).rename(dt))
            residual_hist_ns = pd.DataFrame(ns_rows)
        except Exception as exc:
            diagnostics["ns_history_warning"] = str(exc)

    if "pca_fit" not in cur.columns:
        # Cross-sectional fallback: use NS as PCA stand-in only for app continuity,
        # but label PCA availability explicitly.
        cur["pca_fit"] = np.nan
        cur["pca_resid_bps"] = np.nan
    else:
        cur["pca_resid_bps"] = (cur["ytm"] - cur["pca_fit"]) * 1e4

    if not residual_hist_ns.empty:
        cur["ns_z"] = cur["ticker"].map(historical_residual_zscores(residual_hist_ns, cur.set_index("ticker")["ns_resid_bps"]))
    else:
        cur["ns_z"] = robust_zscore(cur.set_index("ticker")["ns_resid_bps"]).reindex(cur["ticker"]).to_numpy()

    if not residual_hist_pca.empty:
        cur["pca_z"] = cur["ticker"].map(historical_residual_zscores(residual_hist_pca, cur.set_index("ticker")["pca_resid_bps"]))
    else:
        cur["pca_z"] = robust_zscore(cur.set_index("ticker")["pca_resid_bps"]).reindex(cur["ticker"]).to_numpy()

    def label_row(r):
        thr = cfg.z_threshold
        if pd.notna(r["ns_z"]) and pd.notna(r["pca_z"]):
            if r["ns_z"] >= thr and r["pca_z"] >= thr:
                return "CHEAP"
            if r["ns_z"] <= -thr and r["pca_z"] <= -thr:
                return "RICH"
            if np.sign(r["ns_z"]) != np.sign(r["pca_z"]):
                return "DISAGREE"
        return "NEUTRAL"

    cur["rv_label"] = cur.apply(label_row, axis=1)
    cur["agreement_score"] = np.minimum(cur["ns_z"].abs(), cur["pca_z"].abs())
    cur["ytm_pct"] = cur["ytm"] * 100
    cur["ns_fit_pct"] = cur["ns_fit"] * 100
    cur["pca_fit_pct"] = cur["pca_fit"] * 100
    cur["liquidity_weight"] = weights.reindex(cur.index).fillna(1.0)
    diagnostics["yield_history"] = yhist
    diagnostics["residual_hist_ns"] = residual_hist_ns
    diagnostics["residual_hist_pca"] = residual_hist_pca
    diagnostics["pca_model"] = pca_model
    return cur.sort_values("maturity_years"), diagnostics
