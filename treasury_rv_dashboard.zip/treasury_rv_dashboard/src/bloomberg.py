from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import date
from typing import Iterable, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

LOGGER = logging.getLogger(__name__)

DEFAULT_BBG_FIELDS = [
    "PX_BID",
    "PX_ASK",
    "PX_LAST",
    "PX_MID",
    "ACCRUED_INTEREST",
    "CPN",
    "MATURITY",
    "ISSUE_DT",
    "ID_CUSIP",
    "SECURITY_DES",
    "CRNCY",
    "DUR_ADJ_MID",
    "AMT_OUTSTANDING",
    "YLD_YTM_MID",
]


@dataclass
class BloombergResult:
    data: pd.DataFrame
    source: str
    diagnostics: List[str]


def _import_xbbg():
    try:
        from xbbg import blp  # type: ignore

        return blp
    except Exception as exc:  # pragma: no cover - depends on local Bloomberg install
        raise RuntimeError(
            "Could not import xbbg. Install it on the Bloomberg machine with `pip install xbbg`, "
            "and ensure Bloomberg Terminal/BBComm is running."
        ) from exc


def normalize_tickers(raw: str | Iterable[str]) -> List[str]:
    if isinstance(raw, str):
        parts = []
        for line in raw.replace(";", "\n").splitlines():
            parts.extend([p.strip() for p in line.split(",") if p.strip()])
    else:
        parts = [str(x).strip() for x in raw if str(x).strip()]
    seen = set()
    out = []
    for p in parts:
        # Bloomberg government bonds generally need the asset class suffix.
        ticker = p if p.upper().endswith(" GOVT") else f"{p} Govt"
        if ticker not in seen:
            out.append(ticker)
            seen.add(ticker)
    return out


def bbg_reference_data(tickers: Sequence[str], fields: Optional[Sequence[str]] = None) -> BloombergResult:
    """Pull current reference/market fields from Bloomberg using xbbg.bdp.

    Requires Bloomberg Terminal or Bloomberg Server API entitlement on the same host.
    """
    fields = list(fields or DEFAULT_BBG_FIELDS)
    diagnostics: List[str] = []
    blp = _import_xbbg()
    diagnostics.append(f"Calling Bloomberg bdp for {len(tickers)} securities and {len(fields)} fields.")
    df = blp.bdp(tickers=list(tickers), flds=fields)
    if df is None or df.empty:
        raise RuntimeError("Bloomberg returned no reference data. Check ticker format and entitlements.")
    df = df.copy()
    df.index.name = "ticker"
    df = df.reset_index()
    # xbbg may return lowercase columns depending on version/config. Standardize known fields.
    rename = {c: c.upper() for c in df.columns if c != "ticker"}
    df = df.rename(columns=rename)
    if "PX_MID" not in df.columns and {"PX_BID", "PX_ASK"}.issubset(df.columns):
        df["PX_MID"] = (pd.to_numeric(df["PX_BID"], errors="coerce") + pd.to_numeric(df["PX_ASK"], errors="coerce")) / 2
    df["as_of"] = pd.Timestamp.today().normalize()
    return BloombergResult(df, source="Bloomberg/xbbg.bdp", diagnostics=diagnostics)


def bbg_price_history(
    tickers: Sequence[str],
    start_date: date | str,
    end_date: date | str,
    field: str = "PX_LAST",
) -> BloombergResult:
    """Pull historical clean prices using xbbg.bdh.

    Returns a date-indexed DataFrame with one column per ticker.
    """
    blp = _import_xbbg()
    diagnostics = [f"Calling Bloomberg bdh for {len(tickers)} securities, field={field}."]
    raw = blp.bdh(list(tickers), flds=[field], start_date=str(start_date), end_date=str(end_date))
    if raw is None or raw.empty:
        raise RuntimeError("Bloomberg returned no historical price data. Check tickers/date range/entitlements.")
    # xbbg often returns a MultiIndex: columns=(ticker, field). Flatten to tickers.
    hist = raw.copy()
    if isinstance(hist.columns, pd.MultiIndex):
        if field in hist.columns.get_level_values(-1):
            hist = hist.xs(field, axis=1, level=-1, drop_level=True)
        else:
            hist.columns = [str(c[0]) for c in hist.columns]
    hist.index = pd.to_datetime(hist.index).tz_localize(None).normalize()
    hist = hist.apply(pd.to_numeric, errors="coerce")
    return BloombergResult(hist, source="Bloomberg/xbbg.bdh", diagnostics=diagnostics)


def bbg_yield_history(
    tickers: Sequence[str],
    start_date: date | str,
    end_date: date | str,
    field: str = "YLD_YTM_MID",
) -> BloombergResult:
    """Pull historical Bloomberg YTM and return decimal yields.

    Bloomberg yield fields are commonly returned in percent units, so this function
    divides by 100 when the magnitude indicates percent rather than decimal.
    """
    res = bbg_price_history(tickers, start_date, end_date, field=field)
    hist = res.data.astype(float)
    # Convert percent-like yields, e.g. 4.25, to decimals, e.g. 0.0425.
    med_abs = np.nanmedian(np.abs(hist.to_numpy()))
    if np.isfinite(med_abs) and med_abs > 0.5:
        hist = hist / 100.0
    hist.attrs["kind"] = "yield_decimal"
    return BloombergResult(hist, source=f"Bloomberg/xbbg.bdh:{field}", diagnostics=res.diagnostics)


def bbg_accrued_history(
    tickers: Sequence[str],
    start_date: date | str,
    end_date: date | str,
) -> Optional[pd.DataFrame]:
    """Try to pull historical accrued interest. Not all Bloomberg setups expose this via BDH."""
    try:
        return bbg_price_history(tickers, start_date, end_date, field="ACCRUED_INTEREST").data
    except Exception as exc:  # pragma: no cover - Bloomberg-only
        LOGGER.warning("Could not pull historical accrued interest: %s", exc)
        return None


def bql_us_treasury_universe(max_bonds: int = 80) -> BloombergResult:
    """Optional BQL universe pull.

    BQL availability and syntax can vary by Terminal install, so the app treats this
    as optional. If it fails, paste a ticker list from SRCH/GOVT instead.
    """
    diagnostics: List[str] = []
    try:
        import bql  # type: ignore
    except Exception as exc:  # pragma: no cover - depends on local Bloomberg install
        raise RuntimeError(
            "Could not import Bloomberg BQL Python package. Use manual tickers or install/configure BQL."
        ) from exc

    service = bql.Service()
    diagnostics.append("Calling Bloomberg BQL for a US Treasury universe.")
    # This query is deliberately conservative; adjust at your desk if your BQL universe names differ.
    query = f"""
    get(name(), id_cusip(), cpn(), maturity(), px_last(), px_bid(), px_ask(), accrued_interest(), dur_adj_mid(), amt_outstanding())
    for(filter(bonds('US Treasury'), maturity() > today() and crncy() == 'USD'))
    preferences(addcols=all)
    """
    response = service.execute(query)
    df = bql.combined_df(response)
    if df.empty:
        raise RuntimeError("BQL returned no Treasury universe rows.")
    df = df.head(max_bonds).copy()
    # Normalize likely BQL names to the app's canonical names.
    cols = {c: str(c).upper() for c in df.columns}
    df = df.rename(columns=cols)
    if "ID" in df.columns and "ticker" not in df.columns:
        df = df.rename(columns={"ID": "ticker"})
    mapping = {
        "CPN()": "CPN",
        "MATURITY()": "MATURITY",
        "PX_LAST()": "PX_LAST",
        "PX_BID()": "PX_BID",
        "PX_ASK()": "PX_ASK",
        "ACCRUED_INTEREST()": "ACCRUED_INTEREST",
        "DUR_ADJ_MID()": "DUR_ADJ_MID",
        "AMT_OUTSTANDING()": "AMT_OUTSTANDING",
        "ID_CUSIP()": "ID_CUSIP",
        "NAME()": "SECURITY_DES",
    }
    df = df.rename(columns={k: v for k, v in mapping.items() if k in df.columns})
    if "ticker" not in df.columns:
        df = df.reset_index().rename(columns={"index": "ticker"})
    if "PX_MID" not in df.columns and {"PX_BID", "PX_ASK"}.issubset(df.columns):
        df["PX_MID"] = (pd.to_numeric(df["PX_BID"], errors="coerce") + pd.to_numeric(df["PX_ASK"], errors="coerce")) / 2
    df["as_of"] = pd.Timestamp.today().normalize()
    return BloombergResult(df, source="Bloomberg/BQL", diagnostics=diagnostics)
