from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Optional, Tuple

import numpy as np
import pandas as pd
import statsmodels.api as sm

from .curve_models import PCACurveModel, fit_nelson_siegel


@dataclass
class ReversionResult:
    panel: pd.DataFrame
    summary: pd.DataFrame
    pooled_model_text: str
    correlation: float
    hit_rate: float


def _safe_corr(a: pd.Series, b: pd.Series) -> float:
    tmp = pd.concat([a, b], axis=1).dropna()
    if len(tmp) < 5 or tmp.iloc[:, 0].std() == 0 or tmp.iloc[:, 1].std() == 0:
        return np.nan
    return float(tmp.iloc[:, 0].corr(tmp.iloc[:, 1]))


def make_historical_fair_values(
    yield_history: pd.DataFrame,
    n_pca_components: int = 3,
    expanding_window: int = 126,
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """Walk-forward NS and PCA fair values.

    For date t, the PCA model is fit only on data before t. NS is fit on the same-day
    cross-section because it is a cross-sectional curve fit, not a predictive model.
    """
    yhist = yield_history.sort_index().ffill().bfill().dropna(axis=0, how="any")
    ns_fit = pd.DataFrame(index=yhist.index, columns=yhist.columns, dtype=float)
    pca_fit = pd.DataFrame(index=yhist.index, columns=yhist.columns, dtype=float)

    # Static maturity rank proxy for NS in historical panel if exact daily maturity
    # is not passed: interpolate from columns order. This is only for backtest if the
    # full current static mat data is unavailable to this function.
    proxy_tau = np.linspace(0.5, 30.0, yhist.shape[1])
    for dt, row in yhist.iterrows():
        ns = fit_nelson_siegel(proxy_tau, row.values)
        if ns.success:
            ns_fit.loc[dt] = ns.predict(proxy_tau)

    if len(yhist) > expanding_window and yhist.shape[1] >= n_pca_components + 1:
        for idx in range(expanding_window, len(yhist)):
            train = yhist.iloc[:idx]
            model = PCACurveModel(n_components=n_pca_components, standardize=True).fit(train)
            pca_fit.iloc[idx] = model.reconstruct(yhist.iloc[idx]).reindex(yhist.columns).values
    return ns_fit, pca_fit


def analyze_mean_reversion(
    yield_history: pd.DataFrame,
    residual_hist_ns_bps: Optional[pd.DataFrame] = None,
    residual_hist_pca_bps: Optional[pd.DataFrame] = None,
    horizon_days: int = 5,
    z_threshold: float = 1.5,
) -> ReversionResult:
    """Measure whether rich/cheap labels mean revert toward fitted values.

    Signal definition:
      cheap = +1 if both residual z-scores >= threshold
      rich  = -1 if both residual z-scores <= -threshold

    Outcome definition:
      convergence = signal * (residual_t - residual_{t+h})
    Positive convergence means the residual moved toward zero in the expected direction.
    """
    yhist = yield_history.sort_index().dropna(axis=0, how="any")
    if yhist.empty or len(yhist) <= horizon_days + 10:
        return ReversionResult(pd.DataFrame(), pd.DataFrame(), "Not enough history.", np.nan, np.nan)

    if residual_hist_ns_bps is None or residual_hist_pca_bps is None or residual_hist_ns_bps.empty or residual_hist_pca_bps.empty:
        # Fallback: use rolling robust z of yhist demeaned by cross-section mean.
        residual = (yhist.sub(yhist.mean(axis=1), axis=0)) * 1e4
        residual_hist_ns_bps = residual
        residual_hist_pca_bps = residual

    common_idx = residual_hist_ns_bps.index.intersection(residual_hist_pca_bps.index).intersection(yhist.index)
    common_cols = residual_hist_ns_bps.columns.intersection(residual_hist_pca_bps.columns).intersection(yhist.columns)
    ns = residual_hist_ns_bps.loc[common_idx, common_cols].astype(float)
    pca = residual_hist_pca_bps.loc[common_idx, common_cols].astype(float)
    avg_resid = 0.5 * (ns + pca)

    # Expanding z-scores. shift(1) prevents using today's residual in today's standardization window.
    ns_mu = ns.expanding(min_periods=60).mean().shift(1)
    ns_sig = ns.expanding(min_periods=60).std().shift(1).replace(0, np.nan)
    pca_mu = pca.expanding(min_periods=60).mean().shift(1)
    pca_sig = pca.expanding(min_periods=60).std().shift(1).replace(0, np.nan)
    ns_z = (ns - ns_mu) / ns_sig
    pca_z = (pca - pca_mu) / pca_sig

    signal = pd.DataFrame(0, index=common_idx, columns=common_cols, dtype=float)
    signal[(ns_z >= z_threshold) & (pca_z >= z_threshold)] = 1.0
    signal[(ns_z <= -z_threshold) & (pca_z <= -z_threshold)] = -1.0

    future_resid = avg_resid.shift(-horizon_days)
    convergence = signal * (avg_resid - future_resid)
    future_abs_reduction = avg_resid.abs() - future_resid.abs()

    records = []
    for dt in common_idx[:-horizon_days]:
        for sec in common_cols:
            sig = signal.loc[dt, sec]
            if sig == 0 or pd.isna(avg_resid.loc[dt, sec]) or pd.isna(future_resid.loc[dt, sec]):
                continue
            records.append(
                {
                    "date": dt,
                    "ticker": sec,
                    "signal": sig,
                    "label": "CHEAP" if sig > 0 else "RICH",
                    "residual_t_bps": avg_resid.loc[dt, sec],
                    "residual_future_bps": future_resid.loc[dt, sec],
                    "convergence_bps": convergence.loc[dt, sec],
                    "abs_residual_reduction_bps": future_abs_reduction.loc[dt, sec],
                }
            )
    panel = pd.DataFrame(records)
    if panel.empty:
        return ReversionResult(panel, pd.DataFrame(), "No historical signals met the threshold.", np.nan, np.nan)

    panel["hit"] = panel["convergence_bps"] > 0
    panel["signed_residual_bps"] = panel["signal"] * panel["residual_t_bps"]
    corr = _safe_corr(panel["signed_residual_bps"], panel["convergence_bps"])
    hit_rate = float(panel["hit"].mean())

    summary = (
        panel.groupby("label")
        .agg(
            n=("convergence_bps", "size"),
            hit_rate=("hit", "mean"),
            avg_convergence_bps=("convergence_bps", "mean"),
            median_convergence_bps=("convergence_bps", "median"),
            avg_abs_reduction_bps=("abs_residual_reduction_bps", "mean"),
        )
        .reset_index()
    )

    # Pooled time-series/panel regression: Δresidual_h = alpha + beta residual_t.
    # For true mean reversion, beta should be negative.
    reg = panel.dropna(subset=["residual_t_bps", "residual_future_bps"]).copy()
    reg["delta_residual_bps"] = reg["residual_future_bps"] - reg["residual_t_bps"]
    try:
        X = sm.add_constant(reg["residual_t_bps"])
        model = sm.OLS(reg["delta_residual_bps"], X).fit(cov_type="HAC", cov_kwds={"maxlags": max(1, horizon_days)})
        pooled_text = model.summary().as_text()
    except Exception as exc:
        pooled_text = f"Regression failed: {exc}"

    # AR(1) by security, useful half-life diagnostic.
    ar_rows = []
    for sec, g in panel.groupby("ticker"):
        series = avg_resid[sec].dropna()
        if len(series) < 80:
            continue
        y = series.diff().dropna()
        lag = series.shift(1).reindex(y.index)
        try:
            X = sm.add_constant(lag)
            m = sm.OLS(y, X).fit()
            beta = float(m.params.iloc[1])
            phi = 1.0 + beta
            half_life = np.nan
            if 0 < phi < 1:
                half_life = float(-np.log(2) / np.log(phi))
            ar_rows.append({"ticker": sec, "ar_beta": beta, "phi": phi, "half_life_days": half_life, "tstat_beta": float(m.tvalues.iloc[1])})
        except Exception:
            continue
    if ar_rows:
        ar = pd.DataFrame(ar_rows)
        pooled_text += "\n\nAR(1) residual half-life by security (first 15):\n" + ar.head(15).to_string(index=False)

    return ReversionResult(panel, summary, pooled_text, corr, hit_rate)
