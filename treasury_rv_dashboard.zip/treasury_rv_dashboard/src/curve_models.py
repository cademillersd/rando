from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Iterable, Optional, Tuple

import numpy as np
import pandas as pd
from scipy.optimize import minimize, minimize_scalar
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler


EPS = 1e-12


def nelson_siegel_loadings(tau: np.ndarray, lambda_: float) -> np.ndarray:
    """Return [1, slope loading, curvature loading] for Nelson-Siegel."""
    tau = np.asarray(tau, dtype=float)
    x = np.maximum(tau / max(lambda_, EPS), EPS)
    l1 = (1.0 - np.exp(-x)) / x
    l2 = l1 - np.exp(-x)
    return np.column_stack([np.ones_like(tau), l1, l2])


@dataclass
class NelsonSiegelFit:
    beta0: float
    beta1: float
    beta2: float
    lambda_: float
    rmse: float
    success: bool

    def predict(self, tau: Iterable[float]) -> np.ndarray:
        tau = np.asarray(list(tau), dtype=float)
        X = nelson_siegel_loadings(tau, self.lambda_)
        beta = np.array([self.beta0, self.beta1, self.beta2])
        return X @ beta


def fit_nelson_siegel(
    tau: Iterable[float],
    yields: Iterable[float],
    weights: Optional[Iterable[float]] = None,
    lambda_bounds: Tuple[float, float] = (0.15, 15.0),
) -> NelsonSiegelFit:
    """Weighted Nelson-Siegel fit in decimal yield units.

    For a fixed lambda, beta has closed-form weighted least squares. We only search
    lambda. This is stable and fast for minute-by-minute recalculation.
    """
    tau = np.asarray(list(tau), dtype=float)
    y = np.asarray(list(yields), dtype=float)
    mask = np.isfinite(tau) & np.isfinite(y) & (tau > 0)
    tau, y = tau[mask], y[mask]
    if weights is None:
        w = np.ones_like(y)
    else:
        w = np.asarray(list(weights), dtype=float)[mask]
        w = np.where(np.isfinite(w) & (w > 0), w, 1.0)
    if len(y) < 4:
        return NelsonSiegelFit(np.nan, np.nan, np.nan, np.nan, np.nan, False)

    sqrt_w = np.sqrt(w / np.nanmean(w))

    def solve_beta(lambda_: float) -> np.ndarray:
        X = nelson_siegel_loadings(tau, lambda_)
        Xw = X * sqrt_w[:, None]
        yw = y * sqrt_w
        beta, *_ = np.linalg.lstsq(Xw, yw, rcond=None)
        return beta

    def objective(lambda_: float) -> float:
        beta = solve_beta(lambda_)
        resid = y - nelson_siegel_loadings(tau, lambda_) @ beta
        return float(np.average(resid**2, weights=w))

    res = minimize_scalar(objective, bounds=lambda_bounds, method="bounded", options={"xatol": 1e-5})
    lambda_hat = float(res.x)
    beta_hat = solve_beta(lambda_hat)
    resid = y - nelson_siegel_loadings(tau, lambda_hat) @ beta_hat
    rmse = float(np.sqrt(np.average(resid**2, weights=w)))
    return NelsonSiegelFit(
        beta0=float(beta_hat[0]),
        beta1=float(beta_hat[1]),
        beta2=float(beta_hat[2]),
        lambda_=lambda_hat,
        rmse=rmse,
        success=bool(res.success),
    )


class PCACurveModel:
    """PCA fair-yield model fitted on a panel of historical yields.

    Input matrix rows are dates and columns are securities/tenors. The fitted value
    for a current yield vector is its projection onto the top k historical principal
    components, optionally after volatility standardization.
    """

    def __init__(self, n_components: int = 3, standardize: bool = True):
        self.n_components = int(n_components)
        self.standardize = bool(standardize)
        self.columns_: Optional[pd.Index] = None
        self.scaler_: Optional[StandardScaler] = None
        self.pca_: Optional[PCA] = None
        self.explained_variance_ratio_: Optional[np.ndarray] = None
        self.fitted_: bool = False

    def fit(self, yield_history: pd.DataFrame) -> "PCACurveModel":
        hist = yield_history.copy().sort_index()
        hist = hist.dropna(axis=1, how="all")
        hist = hist.ffill().bfill().dropna(axis=0, how="any")
        if hist.shape[0] < max(20, self.n_components + 2) or hist.shape[1] < self.n_components + 1:
            raise ValueError(
                f"Need at least {max(20, self.n_components + 2)} observations and "
                f"{self.n_components + 1} securities for PCA; got {hist.shape}."
            )
        self.columns_ = hist.columns
        X = hist.to_numpy(dtype=float)
        if self.standardize:
            self.scaler_ = StandardScaler(with_mean=True, with_std=True)
            Xs = self.scaler_.fit_transform(X)
        else:
            self.scaler_ = StandardScaler(with_mean=True, with_std=False)
            Xs = self.scaler_.fit_transform(X)
        self.pca_ = PCA(n_components=self.n_components, svd_solver="full", random_state=0)
        self.pca_.fit(Xs)
        self.explained_variance_ratio_ = self.pca_.explained_variance_ratio_
        self.fitted_ = True
        return self

    def reconstruct(self, current_yields: pd.Series) -> pd.Series:
        if not self.fitted_ or self.pca_ is None or self.scaler_ is None or self.columns_ is None:
            raise RuntimeError("PCACurveModel must be fit before reconstruct().")
        y = current_yields.reindex(self.columns_).astype(float)
        if y.isna().any():
            # Fill missing current values with training means in original units.
            means = pd.Series(self.scaler_.mean_, index=self.columns_)
            y = y.fillna(means)
        X = y.to_numpy()[None, :]
        Xs = self.scaler_.transform(X)
        scores = self.pca_.transform(Xs)
        Xhat_s = self.pca_.inverse_transform(scores)
        Xhat = self.scaler_.inverse_transform(Xhat_s)
        return pd.Series(Xhat.ravel(), index=self.columns_, name="pca_fit")

    def component_table(self) -> pd.DataFrame:
        if not self.fitted_ or self.pca_ is None or self.columns_ is None:
            return pd.DataFrame()
        comps = pd.DataFrame(
            self.pca_.components_.T,
            index=self.columns_,
            columns=[f"PC{i+1}" for i in range(self.pca_.n_components_)],
        )
        return comps


def robust_zscore(x: pd.Series) -> pd.Series:
    """Median/MAD z-score fallback for cross-sectional residuals."""
    s = pd.Series(x).astype(float)
    med = s.median(skipna=True)
    mad = (s - med).abs().median(skipna=True)
    denom = 1.4826 * mad if mad and np.isfinite(mad) else s.std(ddof=1)
    if denom is None or denom == 0 or not np.isfinite(denom):
        return pd.Series(np.nan, index=s.index)
    return (s - med) / denom


def historical_residual_zscores(residual_history: pd.DataFrame, current_residuals: pd.Series) -> pd.Series:
    """Z-score current residuals against each security's own residual history."""
    hist = residual_history.copy().replace([np.inf, -np.inf], np.nan)
    mu = hist.mean(axis=0, skipna=True)
    sigma = hist.std(axis=0, skipna=True).replace(0.0, np.nan)
    z = (current_residuals.reindex(hist.columns) - mu) / sigma
    if z.isna().all():
        return robust_zscore(current_residuals)
    return z.reindex(current_residuals.index)
