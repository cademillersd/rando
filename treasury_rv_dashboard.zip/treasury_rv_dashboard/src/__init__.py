"""Treasury relative-value dashboard package."""
