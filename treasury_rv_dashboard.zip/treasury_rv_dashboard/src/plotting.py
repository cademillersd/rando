from __future__ import annotations

import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go

LABEL_COLORS = {
    "CHEAP": "#22C55E",
    "RICH": "#EF4444",
    "NEUTRAL": "#94A3B8",
    "DISAGREE": "#F59E0B",
}


def rv_curve_figure(df: pd.DataFrame) -> go.Figure:
    d = df.sort_values("maturity_years").copy()
    fig = go.Figure()
    fig.add_trace(
        go.Scatter(
            x=d["maturity_years"],
            y=d["ns_fit_pct"],
            mode="lines",
            name="Nelson-Siegel fair yield",
            line=dict(width=3, color="#38BDF8"),
        )
    )
    if d["pca_fit_pct"].notna().any():
        fig.add_trace(
            go.Scatter(
                x=d["maturity_years"],
                y=d["pca_fit_pct"],
                mode="lines",
                name="PCA fair yield",
                line=dict(width=3, dash="dot", color="#A78BFA"),
            )
        )
    for label, g in d.groupby("rv_label"):
        size = 8 + 6 * np.minimum(g["agreement_score"].fillna(0), 4)
        hover = (
            "<b>%{customdata[0]}</b><br>"
            "Maturity: %{x:.2f}y<br>"
            "Observed YTM: %{y:.3f}%<br>"
            "NS residual: %{customdata[1]:.2f} bp<br>"
            "PCA residual: %{customdata[2]:.2f} bp<br>"
            "NS z: %{customdata[3]:.2f}<br>"
            "PCA z: %{customdata[4]:.2f}<br>"
            "DV01/$100: %{customdata[5]:.4f}<extra></extra>"
        )
        fig.add_trace(
            go.Scatter(
                x=g["maturity_years"],
                y=g["ytm_pct"],
                mode="markers",
                name=label,
                marker=dict(size=size, color=LABEL_COLORS.get(label, "#CBD5E1"), line=dict(width=1, color="#E5E7EB")),
                customdata=np.column_stack(
                    [
                        g["ticker"],
                        g["ns_resid_bps"],
                        g["pca_resid_bps"],
                        g["ns_z"],
                        g["pca_z"],
                        g["dv01_100"],
                    ]
                ),
                hovertemplate=hover,
            )
        )
    fig.update_layout(
        template="plotly_dark",
        height=580,
        paper_bgcolor="#020617",
        plot_bgcolor="#020617",
        title="Live Treasury Curve: Observed Bonds vs Fair-Value Curves",
        xaxis_title="Years to maturity",
        yaxis_title="Yield to maturity (%)",
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
        margin=dict(l=30, r=30, t=70, b=30),
    )
    fig.update_xaxes(gridcolor="#1E293B")
    fig.update_yaxes(gridcolor="#1E293B")
    return fig


def residual_bar_figure(df: pd.DataFrame, model: str = "ns") -> go.Figure:
    resid_col = f"{model}_resid_bps"
    z_col = f"{model}_z"
    title = "Nelson-Siegel residuals" if model == "ns" else "PCA residuals"
    d = df.sort_values("maturity_years").copy()
    fig = go.Figure(
        go.Bar(
            x=d["maturity_years"],
            y=d[resid_col],
            marker_color=[LABEL_COLORS.get(x, "#94A3B8") for x in d["rv_label"]],
            customdata=np.column_stack([d["ticker"], d[z_col], d["rv_label"]]),
            hovertemplate="<b>%{customdata[0]}</b><br>Maturity: %{x:.2f}y<br>Residual: %{y:.2f} bp<br>z: %{customdata[1]:.2f}<br>Label: %{customdata[2]}<extra></extra>",
        )
    )
    fig.add_hline(y=0, line_width=1, line_dash="dash", line_color="#CBD5E1")
    fig.update_layout(
        template="plotly_dark",
        paper_bgcolor="#020617",
        plot_bgcolor="#020617",
        title=title,
        xaxis_title="Years to maturity",
        yaxis_title="Observed yield - fitted yield (bp)",
        height=360,
        margin=dict(l=30, r=30, t=50, b=30),
    )
    fig.update_xaxes(gridcolor="#1E293B")
    fig.update_yaxes(gridcolor="#1E293B")
    return fig


def pca_explained_variance_figure(ratios) -> go.Figure:
    if ratios is None or len(ratios) == 0:
        return go.Figure()
    x = [f"PC{i+1}" for i in range(len(ratios))]
    fig = go.Figure(go.Bar(x=x, y=np.array(ratios) * 100, marker_color="#38BDF8"))
    fig.update_layout(
        template="plotly_dark",
        paper_bgcolor="#020617",
        plot_bgcolor="#020617",
        title="PCA explained variance",
        yaxis_title="Variance explained (%)",
        height=300,
        margin=dict(l=30, r=30, t=50, b=30),
    )
    fig.update_yaxes(gridcolor="#1E293B")
    return fig


def reversion_scatter(panel: pd.DataFrame) -> go.Figure:
    if panel is None or panel.empty:
        return go.Figure()
    fig = px.scatter(
        panel,
        x="signed_residual_bps",
        y="convergence_bps",
        color="label",
        color_discrete_map=LABEL_COLORS,
        hover_data=["date", "ticker", "residual_t_bps", "residual_future_bps"],
        template="plotly_dark",
        title="Signal strength vs future residual convergence",
    )
    fig.add_hline(y=0, line_width=1, line_dash="dash", line_color="#CBD5E1")
    fig.update_layout(
        paper_bgcolor="#020617",
        plot_bgcolor="#020617",
        xaxis_title="Signed residual at signal date (bp)",
        yaxis_title="Future convergence toward fair value (bp)",
        height=450,
        margin=dict(l=30, r=30, t=50, b=30),
    )
    fig.update_xaxes(gridcolor="#1E293B")
    fig.update_yaxes(gridcolor="#1E293B")
    return fig
