# Treasury Relative-Value Engine

A local Streamlit dashboard for a rates desk workflow:

- Pulls real Treasury bond pricing/reference data through Bloomberg via `xbbg` / `blpapi`.
- Solves each bond's implied yield from clean price + accrued interest.
- Fits a Nelson-Siegel fair curve.
- Fits a PCA fair-yield reconstruction from historical yield panels.
- Labels a bond **CHEAP** or **RICH** only when Nelson-Siegel and PCA residual z-scores agree.
- Tests whether historical rich/cheap residuals mean revert back toward fitted values.
- Provides a high-contrast dark Streamlit UI with a separate math tab.

## Important Bloomberg notes

This project includes real Bloomberg API calls, but they only work on a machine with Bloomberg Terminal/BBComm or Bloomberg Server API access and the correct entitlements. Bloomberg data should remain inside the entitled local environment and follow your firm's data policy.

The most reliable setup is to paste actual Treasury tickers from Bloomberg `SRCH <GO>` / `GOVT <GO>` into the app. The app also includes an optional BQL universe hook, but BQL availability and syntax can vary by Terminal configuration.

## Install

```bash
cd treasury_rv_dashboard
python -m venv .venv
.venv\Scripts\activate        # Windows
# source .venv/bin/activate   # macOS/Linux
pip install -r requirements.txt
```

If Bloomberg's `blpapi` is not installed automatically on your machine, install it using your firm's approved Bloomberg API installation method, then reinstall `xbbg` if needed.

## Run

```bash
streamlit run app.py
```

Start in **Demo synthetic data** mode to verify the UI and calculations. Then switch to **Bloomberg real data** and paste tickers, for example:

```text
T 4.25 05/31/26 Govt
T 4.625 06/15/27 Govt
T 4.25 05/15/34 Govt
```

## Model interpretation

For each bond:

```text
residual = observed yield - fitted yield
```

- Positive residual: observed yield is high vs fair value, so the bond is cheap on yield.
- Negative residual: observed yield is low vs fair value, so the bond is rich on yield.
- Strong label only appears when both Nelson-Siegel and PCA z-scores breach the threshold in the same direction.

## Production improvements

For a desk-quality version, replace the approximate cashflow schedule with QuantLib or Bloomberg/YAS cashflows, add futures CTD/basis, add repo specialness, add auction-cycle controls, and compute PnL through DV01-neutral hedge baskets rather than residual convergence alone.
