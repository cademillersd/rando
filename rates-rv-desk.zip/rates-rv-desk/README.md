# Rates RV Desk Assistant

A Python project scaffold for a Treasury rates trading desk workflow:

1. Ingest a ticket / bond universe from RiskVal, REST, or CSV.
2. Fit Treasury curves and compute fitted-value residuals.
3. Run PCA on historical yield curves to decompose level/slope/curvature.
4. Rank bonds and curve structures by richness/cheapness.
5. Suggest DV01/futures hedges and show residual exposure.
6. Produce a trader-friendly Streamlit dashboard and CLI scanner.

This is designed to sit beside RiskVal/ION/Bloomberg rather than replace them.
RiskVal method names and authentication are usually proprietary/desk-specific, so the integration layer is intentionally isolated and configurable.

---

## What this project does

### Core analytics

- **PCA factor model** on Treasury yield history.
- **Fitted curve residuals** using cubic spline or polynomial curve fit.
- **Rich/cheap z-scores** using historical residuals.
- **On-the-run vs off-the-run comparison**.
- **Butterfly scanner** for structures like 2s5s10s, 5s10s30s.
- **Ticket enrichment**: bond metadata, fitted yield, residual, percentile, z-score.
- **Hedge helper**: futures or benchmark-bond DV01 hedge sizing.

### Integrations

- `RiskValRVPythonClient`: imports desk-installed RVPython module and calls configured function names.
- `RiskValRESTClient`: generic REST adapter if your desk exposes RiskVal/internal data through HTTP.
- `CSVMarketDataClient`: local fallback for development and demos.
- `MockRiskValClient`: deterministic sample data generator.

---

## Quick start

```bash
cd rates-rv-desk
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python scripts/generate_sample_data.py
python scripts/run_scan.py --data-dir data/sample --top 10
streamlit run src/rates_rv/app.py -- --data-dir data/sample
```

---

## Using RiskVal / RVPython

Public RiskVal materials mention RVExcel/RVPython, but the actual method names are generally not public and may differ by desk install. This project handles that by reading function names from YAML.

1. Ask the desk or RiskVal support for the exact RVPython import/module and function names for:
   - Treasury curve history
   - current Treasury bond universe
   - ticket/blotter data, if permissioned
   - futures DV01 / hedge ratios, if available
2. Copy the example config:

```bash
cp config/riskval_mapping.example.yaml config/riskval_mapping.local.yaml
```

3. Edit function names in the YAML.
4. Set environment variables:

```bash
export RISKVAL_BACKEND=rvpython
export RISKVAL_RVPYTHON_MODULE=rvpython
export RISKVAL_MAPPING=config/riskval_mapping.local.yaml
```

5. Use the adapter:

```python
from rates_rv.integrations.riskval import RiskValRVPythonClient

client = RiskValRVPythonClient.from_env()
yield_history = client.get_yield_history()
bond_universe = client.get_bond_universe()
```

If your desk exposes an internal REST wrapper instead:

```bash
export RISKVAL_BACKEND=rest
export RISKVAL_REST_BASE_URL="https://internal-riskval-wrapper.yourbank.net"
export RISKVAL_REST_TOKEN="..."
```

Then use `RiskValRESTClient.from_env()`.

---

## Data contracts

### Yield history CSV

`data/sample/yield_history.csv`

Required columns:

- `date`
- one column per maturity in years, e.g. `0.25`, `0.5`, `1`, `2`, `3`, `5`, `7`, `10`, `20`, `30`

Values should be yields in **percent**, e.g. `4.25` for 4.25%.

### Bond universe CSV

`data/sample/bonds.csv`

Required columns:

- `cusip`
- `description`
- `maturity_date`
- `coupon_pct`
- `yield_pct`
- `price`
- `dv01_per_1mm`
- `issue_size_mm`
- `is_otr`

Optional columns:

- `sector`
- `bid_yield_pct`
- `ask_yield_pct`
- `liquidity_score`

### Tickets CSV

`data/sample/tickets.csv`

Required columns:

- `ticket_id`
- `timestamp`
- `side` (`BUY` or `SELL` from client perspective)
- `cusip`
- `notional_mm`

---

## Key design idea

Do not try to replace the trader's judgment. The highest-value desk tool is a fast decision card:

> Given this ticket, is the bond rich or cheap to curve, what are the relevant RV structures, what hedge size is needed, and what residual curve exposure remains?

---

## Compliance / desk usage note

Do not connect this to production trade, order, ticket, or client-flow data without approval from the desk, compliance, technology, and data owners. The project is written so that proprietary data adapters are isolated from open-source analytics code.
