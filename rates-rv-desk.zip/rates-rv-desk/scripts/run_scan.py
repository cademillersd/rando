from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

import pandas as pd

from rates_rv.analytics.curve import latest_curve_from_history
from rates_rv.analytics.pca import YieldCurvePCA
from rates_rv.analytics.rv import TreasuryRVEngine, top_rich_cheap
from rates_rv.analytics.ticket import enrich_ticket
from rates_rv.integrations.factory import make_client


def main() -> None:
    parser = argparse.ArgumentParser(description="Run Treasury RV scan")
    parser.add_argument("--backend", default="csv", choices=["csv", "mock", "rvpython", "rest"])
    parser.add_argument("--data-dir", default=str(ROOT / "data" / "sample"))
    parser.add_argument("--top", type=int, default=10)
    args = parser.parse_args()

    client = make_client(backend=args.backend, data_dir=args.data_dir)
    yield_history = client.get_yield_history()
    bonds = client.get_bond_universe()
    futures = client.get_futures_analytics()
    tickets = client.get_tickets()

    curve = latest_curve_from_history(yield_history)
    rv_engine = TreasuryRVEngine(yield_history, curve)
    scored = rv_engine.score_bonds(bonds)

    print("\n=== Top rich/cheap bonds ===")
    print(top_rich_cheap(scored, n=args.top).to_string(index=False))

    print("\n=== Butterfly scanner ===")
    print(rv_engine.butterfly_scan().to_string(index=False))

    pca = YieldCurvePCA(n_components=3).fit(yield_history)
    evr = pd.Series(pca.explained_variance_ratio_, index=["PC1", "PC2", "PC3"])
    print("\n=== PCA explained variance ===")
    print((100 * evr).round(2).astype(str) + "%")

    if not tickets.empty:
        print("\n=== First ticket enrichment ===")
        card = enrich_ticket(tickets.iloc[0], bonds, rv_engine, futures)
        print(card["decision_note"])
        bond_keys = ["cusip", "description", "rv_label", "residual_bp", "residual_z", "nearest_otr_cusip", "spread_to_nearest_otr_bp"]
        print({k: card["bond"].get(k) for k in bond_keys})
        if not card["future_hedges"].empty:
            print("\nFuture hedge candidates:")
            print(card["future_hedges"].head(3).to_string(index=False))


if __name__ == "__main__":
    main()
