from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from rates_rv.integrations.mock_client import MockRiskValClient


def main() -> None:
    out_dir = ROOT / "data" / "sample"
    out_dir.mkdir(parents=True, exist_ok=True)
    client = MockRiskValClient()
    client.get_yield_history().to_csv(out_dir / "yield_history.csv", index=False)
    client.get_bond_universe().to_csv(out_dir / "bonds.csv", index=False)
    client.get_tickets().to_csv(out_dir / "tickets.csv", index=False)
    client.get_futures_analytics().to_csv(out_dir / "futures.csv", index=False)
    print(f"Wrote sample data to {out_dir}")


if __name__ == "__main__":
    main()
