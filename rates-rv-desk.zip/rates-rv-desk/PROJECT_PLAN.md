# Build Plan: Treasury Ticket RV + Hedge Assistant

## Step 1 — Data layer

Build adapters for the systems traders already use:

- RiskVal/RVPython for yields, curves, DV01, bond universe, and possibly tickets.
- Internal REST wrappers if the bank exposes approved APIs.
- CSV/mock fallback for local development.
- Optional ION REST wrapper for order book/ticket state if approved.

The key engineering principle is to keep proprietary system access in `src/rates_rv/integrations/` and keep analytics independent.

## Step 2 — Ticket enrichment

When a ticket arrives, normalize:

- CUSIP
- client side
- notional
- maturity
- coupon
- current yield
- DV01
- OTR/off-the-run status

Then attach analytics from the RV engine.

## Step 3 — PCA curve model

Use historical Treasury yield changes to estimate the first three factors:

- PC1: level
- PC2: slope
- PC3: curvature

Output:

- factor loadings
- explained variance
- latest factor scores
- maturity-sector residuals

## Step 4 — Fitted-curve richness/cheapness

Fit a Treasury curve from liquid curve points, then calculate:

- actual yield
- fitted yield
- residual in bp
- historical residual z-score
- percentile
- rich/cheap label
- spread to nearest OTR

Interpretation:

- Positive residual = higher yield than fitted curve = cheap bond.
- Negative residual = lower yield than fitted curve = rich bond.

## Step 5 — Butterfly and curve context

Calculate standard flies:

- 2s5s10s
- 5s10s30s
- 2s7s10s
- 3s5s7s
- 7s10s30s

Rank by z-score and percentile.

## Step 6 — Hedge assistant

Given the ticket and bond DV01:

- calculate desk DV01 after client flow
- choose candidate futures by maturity bucket
- compute contracts needed
- show residual DV01 after rounding
- show rough key-rate exposure fallback if RiskVal KRD is unavailable

## Step 7 — Pre-trade checklist

Before execution, show:

- RV label
- residual and z-score
- desk long/short direction
- DV01
- closest futures hedge
- residual DV01
- order-book depth if ION data is available

## Step 8 — Dashboard / CLI

Provide:

- CLI scanner for fast terminal output
- Streamlit app for desk-demo visualization
- sample data generator so the project runs before credentials are available
