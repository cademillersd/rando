from __future__ import annotations

from rates_rv.analytics.curve import latest_curve_from_history
from rates_rv.analytics.pca import YieldCurvePCA
from rates_rv.analytics.rv import TreasuryRVEngine, top_rich_cheap
from rates_rv.analytics.ticket import enrich_ticket
from rates_rv.integrations.mock_client import MockRiskValClient


def test_rv_engine_scores_bonds():
    client = MockRiskValClient()
    hist = client.get_yield_history()
    bonds = client.get_bond_universe()
    curve = latest_curve_from_history(hist)
    engine = TreasuryRVEngine(hist, curve)
    scored = engine.score_bonds(bonds)
    assert "residual_z" in scored.columns
    assert len(top_rich_cheap(scored, n=5)) == 5


def test_pca_fits_three_components():
    client = MockRiskValClient()
    hist = client.get_yield_history()
    model = YieldCurvePCA(n_components=3).fit(hist)
    assert model.components_.shape[0] == 3
    assert model.factor_loadings().shape[1] == 3


def test_ticket_enrichment_has_hedge_candidates():
    client = MockRiskValClient()
    hist = client.get_yield_history()
    bonds = client.get_bond_universe()
    tickets = client.get_tickets()
    futures = client.get_futures_analytics()
    engine = TreasuryRVEngine(hist, latest_curve_from_history(hist))
    card = enrich_ticket(tickets.iloc[0], bonds, engine, futures)
    assert "decision_note" in card
    assert not card["future_hedges"].empty
