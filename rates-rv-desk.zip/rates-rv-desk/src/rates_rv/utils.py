from __future__ import annotations

from datetime import date, datetime
from pathlib import Path
from typing import Iterable

import numpy as np
import pandas as pd


def years_to_maturity(maturity_date: str | date | pd.Timestamp, as_of: str | date | pd.Timestamp | None = None) -> float:
    as_of_date = pd.Timestamp(as_of or pd.Timestamp.today().normalize())
    maturity = pd.Timestamp(maturity_date)
    return max((maturity - as_of_date).days / 365.25, 0.0)


def ensure_datetime_index(df: pd.DataFrame, date_col: str = "date") -> pd.DataFrame:
    out = df.copy()
    if date_col in out.columns:
        out[date_col] = pd.to_datetime(out[date_col])
        out = out.set_index(date_col)
    if not isinstance(out.index, pd.DatetimeIndex):
        raise ValueError(f"Expected DatetimeIndex or a '{date_col}' column.")
    out = out.sort_index()
    return out


def parse_maturity_columns(columns: Iterable[str]) -> list[float]:
    maturities: list[float] = []
    for c in columns:
        try:
            maturities.append(float(c))
        except ValueError as exc:
            raise ValueError(f"Yield history columns must be maturities in years. Bad column: {c!r}") from exc
    return maturities


def bp(x_pct: float | pd.Series | np.ndarray) -> float | pd.Series | np.ndarray:
    """Percent-yield difference to basis points."""
    return 100.0 * x_pct


def pct_from_bp(x_bp: float | pd.Series | np.ndarray) -> float | pd.Series | np.ndarray:
    return x_bp / 100.0


def rolling_zscore(series: pd.Series, window: int = 252, min_periods: int = 60) -> pd.Series:
    mean = series.rolling(window, min_periods=min_periods).mean()
    std = series.rolling(window, min_periods=min_periods).std(ddof=1)
    return (series - mean) / std.replace(0, np.nan)


def empirical_percentile(history: pd.Series, value: float) -> float | None:
    clean = history.dropna().astype(float)
    if clean.empty:
        return None
    return float((clean <= value).mean())


def project_root_from_file(path: str | Path) -> Path:
    return Path(path).resolve().parent
