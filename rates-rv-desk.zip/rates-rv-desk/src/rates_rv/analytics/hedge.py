from __future__ import annotations

import numpy as np
import pandas as pd

from rates_rv.utils import years_to_maturity


def ticket_dv01(ticket: pd.Series | dict, bond_row: pd.Series | dict) -> float:
    t = pd.Series(ticket)
    b = pd.Series(bond_row)
    return float(t["notional_mm"]) * float(b["dv01_per_1mm"])


def recommend_single_future_hedge(ticket: pd.Series | dict, bond_row: pd.Series | dict, futures: pd.DataFrame) -> pd.DataFrame:
    """Recommend hedge contracts by closest maturity bucket.

    Sign convention:
    - Ticket side is from the client's perspective.
    - If client BUYs bond, desk SELLs bond, so desk has negative bond DV01 and should BUY futures to hedge.
    - If client SELLs bond, desk BUYs bond, so desk has positive bond DV01 and should SELL futures to hedge.
    """
    t = pd.Series(ticket)
    b = pd.Series(bond_row)
    if futures.empty:
        return pd.DataFrame()
    bond_mat = b.get("maturity_years")
    if bond_mat is None:
        bond_mat = years_to_maturity(b["maturity_date"])
    fut = futures.copy()
    fut["distance"] = (fut["maturity_bucket"].astype(float) - float(bond_mat)).abs()
    fut = fut.sort_values("distance")
    desk_dv01 = ticket_dv01(t, b) * (1 if str(t["side"]).upper() == "SELL" else -1)
    rows = []
    for _, f in fut.iterrows():
        contracts = -desk_dv01 / float(f["dv01_per_contract"])
        rows.append(
            {
                "symbol": f["symbol"],
                "description": f.get("description", f["symbol"]),
                "maturity_bucket": f.get("maturity_bucket"),
                "dv01_per_contract": f["dv01_per_contract"],
                "desk_bond_dv01": desk_dv01,
                "hedge_contracts": int(round(contracts)),
                "hedge_action": "BUY" if contracts > 0 else "SELL",
                "residual_dv01_after_rounding": desk_dv01 + int(round(contracts)) * float(f["dv01_per_contract"]),
            }
        )
    return pd.DataFrame(rows).sort_values("distance" if "distance" in rows else "maturity_bucket").drop(columns=["distance"], errors="ignore")


def dv01_neutral_benchmark_hedge(ticket: pd.Series | dict, bond_row: pd.Series | dict, hedge_bond: pd.Series | dict) -> dict:
    t = pd.Series(ticket)
    b = pd.Series(bond_row)
    h = pd.Series(hedge_bond)
    desk_dv01 = ticket_dv01(t, b) * (1 if str(t["side"]).upper() == "SELL" else -1)
    hedge_notional_mm = -desk_dv01 / float(h["dv01_per_1mm"])
    return {
        "hedge_cusip": h["cusip"],
        "hedge_description": h["description"],
        "desk_bond_dv01": desk_dv01,
        "hedge_notional_mm": hedge_notional_mm,
        "hedge_action": "BUY" if hedge_notional_mm > 0 else "SELL",
    }


def residual_key_rate_exposure(ticket: pd.Series | dict, bond_row: pd.Series | dict, tenors=(2, 5, 7, 10, 20, 30)) -> pd.DataFrame:
    """Simple Gaussian key-rate allocation for a ticket.

    This is not a replacement for RiskVal KRD. It is a fallback visualization when
    only maturity and DV01 are available.
    """
    t = pd.Series(ticket)
    b = pd.Series(bond_row)
    maturity = float(b.get("maturity_years", years_to_maturity(b["maturity_date"])))
    total = ticket_dv01(t, b) * (1 if str(t["side"]).upper() == "SELL" else -1)
    tenors = np.array(tenors, dtype=float)
    weights = np.exp(-0.5 * ((tenors - maturity) / 2.0) ** 2)
    weights = weights / weights.sum()
    return pd.DataFrame({"tenor": tenors, "dv01": total * weights})
