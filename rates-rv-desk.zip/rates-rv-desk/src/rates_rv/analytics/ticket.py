from __future__ import annotations

import pandas as pd

from rates_rv.analytics.hedge import recommend_single_future_hedge, residual_key_rate_exposure, ticket_dv01
from rates_rv.analytics.rv import TreasuryRVEngine


def enrich_ticket(
    ticket: pd.Series | dict,
    bonds: pd.DataFrame,
    rv_engine: TreasuryRVEngine,
    futures: pd.DataFrame | None = None,
) -> dict:
    t = pd.Series(ticket)
    scored = rv_engine.score_bonds(bonds)
    match = scored[scored["cusip"].astype(str).str.upper() == str(t["cusip"]).upper()]
    if match.empty:
        raise ValueError(f"CUSIP {t['cusip']} not found")
    bond = match.iloc[0]
    desk_position = "SHORT_BOND" if str(t["side"]).upper() == "BUY" else "LONG_BOND"
    decision_note = _decision_note(str(t["side"]).upper(), str(bond["rv_label"]))
    hedge = recommend_single_future_hedge(t, bond, futures if futures is not None else pd.DataFrame())
    krd = residual_key_rate_exposure(t, bond)
    return {
        "ticket": t.to_dict(),
        "bond": bond.to_dict(),
        "desk_position": desk_position,
        "ticket_dv01": ticket_dv01(t, bond),
        "decision_note": decision_note,
        "future_hedges": hedge,
        "key_rate_exposure": krd,
    }


def _decision_note(client_side: str, rv_label: str) -> str:
    # Client side from incoming ticket. Desk does the opposite side.
    if client_side == "BUY" and rv_label == "RICH":
        return "Client buys; desk sells a rich bond. RV context is favorable, subject to liquidity/flow."
    if client_side == "BUY" and rv_label == "CHEAP":
        return "Client buys; desk sells a cheap bond. Be careful: RV context works against the desk sale."
    if client_side == "SELL" and rv_label == "CHEAP":
        return "Client sells; desk buys a cheap bond. RV context is favorable, subject to inventory/risk."
    if client_side == "SELL" and rv_label == "RICH":
        return "Client sells; desk buys a rich bond. Be careful: RV context works against the desk buy."
    return "RV context is neutral. Price/liquidity/flow likely matter more than fitted-curve signal."
