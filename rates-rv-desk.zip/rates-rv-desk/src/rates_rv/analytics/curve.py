from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

import numpy as np
import pandas as pd
from scipy.interpolate import CubicSpline, PchipInterpolator

from rates_rv.utils import bp, ensure_datetime_index, parse_maturity_columns, years_to_maturity

CurveMethod = Literal["pchip", "cubic", "poly"]


@dataclass
class FittedCurve:
    maturities: np.ndarray
    yields_pct: np.ndarray
    method: CurveMethod = "pchip"
    poly_degree: int = 4

    def __post_init__(self) -> None:
        order = np.argsort(self.maturities)
        self.maturities = np.asarray(self.maturities, dtype=float)[order]
        self.yields_pct = np.asarray(self.yields_pct, dtype=float)[order]
        if len(self.maturities) != len(self.yields_pct):
            raise ValueError("maturities and yields_pct must have same length")
        if len(self.maturities) < 3:
            raise ValueError("Need at least 3 curve points")
        if self.method == "pchip":
            self._model = PchipInterpolator(self.maturities, self.yields_pct, extrapolate=True)
        elif self.method == "cubic":
            self._model = CubicSpline(self.maturities, self.yields_pct, extrapolate=True)
        elif self.method == "poly":
            degree = min(self.poly_degree, len(self.maturities) - 1)
            self._coef = np.polyfit(self.maturities, self.yields_pct, deg=degree)
            self._model = None
        else:
            raise ValueError(f"Unknown method {self.method}")

    def predict(self, maturity_years: float | np.ndarray) -> float | np.ndarray:
        x = np.asarray(maturity_years, dtype=float)
        if self.method == "poly":
            y = np.polyval(self._coef, x)
        else:
            y = self._model(x)
        if np.ndim(maturity_years) == 0:
            return float(y)
        return y


def latest_curve_from_history(yield_history: pd.DataFrame, method: CurveMethod = "pchip") -> FittedCurve:
    hist = ensure_datetime_index(yield_history)
    maturities = np.array(parse_maturity_columns(hist.columns), dtype=float)
    yields = hist.iloc[-1].astype(float).values
    return FittedCurve(maturities=maturities, yields_pct=yields, method=method)


def fit_curve_from_bonds(bonds: pd.DataFrame, as_of: str | pd.Timestamp | None = None, method: CurveMethod = "pchip") -> FittedCurve:
    df = bonds.copy()
    df["maturity_years"] = df["maturity_date"].map(lambda d: years_to_maturity(d, as_of))
    liquid = df[df["is_otr"].astype(bool)] if "is_otr" in df.columns else df
    if len(liquid) < 3:
        liquid = df
    return FittedCurve(liquid["maturity_years"].values, liquid["yield_pct"].values, method=method)


def add_curve_residuals(
    bonds: pd.DataFrame,
    curve: FittedCurve,
    as_of: str | pd.Timestamp | None = None,
) -> pd.DataFrame:
    out = bonds.copy()
    out["maturity_years"] = out["maturity_date"].map(lambda d: years_to_maturity(d, as_of))
    out["fitted_yield_pct"] = curve.predict(out["maturity_years"].values)
    out["residual_bp"] = bp(out["yield_pct"] - out["fitted_yield_pct"])
    return out


def historical_fitted_residuals(
    yield_history: pd.DataFrame,
    method: CurveMethod = "pchip",
    leave_one_out: bool = True,
) -> pd.DataFrame:
    """Compute historical curve residuals at each quoted maturity.

    For each day and tenor, fit the curve to the other tenors and measure the
    quoted yield minus fitted yield. This approximates a historical distribution
    for rich/cheap z-scores when you do not have historical CUSIP-level data.
    """
    hist = ensure_datetime_index(yield_history)
    maturities = np.array(parse_maturity_columns(hist.columns), dtype=float)
    rows = []
    for dt, row in hist.iterrows():
        yields = row.astype(float).values
        residuals = {}
        for i, mat in enumerate(maturities):
            if leave_one_out and len(maturities) > 4:
                mask = np.arange(len(maturities)) != i
                model = FittedCurve(maturities[mask], yields[mask], method=method)
                fitted = model.predict(mat)
            else:
                model = FittedCurve(maturities, yields, method=method)
                fitted = model.predict(mat)
            residuals[str(mat)] = float(bp(yields[i] - fitted))
        rows.append((dt, residuals))
    out = pd.DataFrame([r for _, r in rows], index=[dt for dt, _ in rows])
    out.index.name = "date"
    return out


def interpolate_history_to_maturity(residual_history: pd.DataFrame, maturity_years: float) -> pd.Series:
    """Approximate historical residual series for an arbitrary maturity.

    Uses the residual history at the nearest quoted tenor.
    """
    cols = np.array([float(c) for c in residual_history.columns])
    nearest = str(cols[np.argmin(np.abs(cols - maturity_years))])
    return residual_history[nearest]
