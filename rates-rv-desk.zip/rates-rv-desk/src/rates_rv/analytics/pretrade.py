from __future__ import annotations

import numpy as np
import pandas as pd


def summarize_order_book(order_book: pd.DataFrame, notional_mm: float) -> dict:
    """Summarize simple order-book depth.

    Expected columns if available: side, price, yield_pct, size_mm. This is an
    optional ION/internal-data helper; if the desk does not grant order-book data,
    the rest of the project still works.
    """
    if order_book is None or order_book.empty:
        return {"available": False, "note": "No order book supplied."}
    ob = order_book.copy()
    if "size_mm" not in ob.columns:
        return {"available": True, "note": "Order book supplied but missing size_mm."}
    bid_depth = ob[ob.get("side", "").astype(str).str.upper() == "BID"]["size_mm"].sum()
    ask_depth = ob[ob.get("side", "").astype(str).str.upper() == "ASK"]["size_mm"].sum()
    return {
        "available": True,
        "bid_depth_mm": float(bid_depth),
        "ask_depth_mm": float(ask_depth),
        "ticket_notional_mm": float(notional_mm),
        "bid_depth_ratio": float(bid_depth / notional_mm) if notional_mm else np.nan,
        "ask_depth_ratio": float(ask_depth / notional_mm) if notional_mm else np.nan,
    }


def execution_checklist(ticket_card: dict, order_book: pd.DataFrame | None = None) -> list[str]:
    """Generate a simple pre-trade checklist from ticket enrichment."""
    ticket = ticket_card["ticket"]
    bond = ticket_card["bond"]
    checks = []
    checks.append(f"Ticket {ticket['ticket_id']}: {ticket['side']} {ticket['notional_mm']}mm {bond['description']} ({bond['cusip']}).")
    checks.append(f"RV label: {bond.get('rv_label')} | residual: {bond.get('residual_bp'):.2f} bp | z: {bond.get('residual_z'):.2f}.")
    checks.append(f"Desk position after client flow: {ticket_card['desk_position']} | ticket DV01: ${ticket_card['ticket_dv01']:.0f}/bp.")
    hedge = ticket_card.get("future_hedges")
    if isinstance(hedge, pd.DataFrame) and not hedge.empty:
        best = hedge.iloc[0]
        checks.append(
            f"Closest futures hedge candidate: {best['hedge_action']} {best['hedge_contracts']} {best['symbol']} "
            f"with residual DV01 ${best['residual_dv01_after_rounding']:.0f}/bp."
        )
    depth = summarize_order_book(order_book, ticket["notional_mm"])
    if depth.get("available"):
        checks.append(f"Order-book depth: bid {depth.get('bid_depth_mm', 0):.1f}mm / ask {depth.get('ask_depth_mm', 0):.1f}mm.")
    else:
        checks.append("Order-book depth: not supplied; verify liquidity in ION/Bloomberg before execution.")
    return checks
