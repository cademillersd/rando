from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd

from rates_rv.utils import ensure_datetime_index, parse_maturity_columns


@dataclass
class YieldCurvePCA:
    n_components: int = 3
    standardize: bool = False
    maturities_: np.ndarray | None = None
    mean_: np.ndarray | None = None
    std_: np.ndarray | None = None
    components_: np.ndarray | None = None
    explained_variance_ratio_: np.ndarray | None = None
    scores_: pd.DataFrame | None = None

    def fit(self, yield_history: pd.DataFrame, use_changes: bool = True) -> "YieldCurvePCA":
        hist = ensure_datetime_index(yield_history)
        self.maturities_ = np.array(parse_maturity_columns(hist.columns), dtype=float)
        x = hist.diff().dropna() if use_changes else hist.copy()
        matrix = x.astype(float).values
        self.mean_ = matrix.mean(axis=0)
        centered = matrix - self.mean_
        if self.standardize:
            self.std_ = centered.std(axis=0, ddof=1)
            centered = centered / np.where(self.std_ == 0, 1.0, self.std_)
        else:
            self.std_ = np.ones(centered.shape[1])

        _, singular_values, vt = np.linalg.svd(centered, full_matrices=False)
        self.components_ = vt[: self.n_components]
        eigenvalues = singular_values**2 / max(len(centered) - 1, 1)
        self.explained_variance_ratio_ = eigenvalues[: self.n_components] / eigenvalues.sum()
        scores = centered @ self.components_.T
        self.scores_ = pd.DataFrame(scores, index=x.index, columns=[f"PC{i+1}" for i in range(self.n_components)])
        return self

    def transform(self, yield_changes: pd.DataFrame) -> pd.DataFrame:
        if self.components_ is None or self.mean_ is None or self.std_ is None:
            raise RuntimeError("Call fit first.")
        x = yield_changes.astype(float).values
        centered = (x - self.mean_) / np.where(self.std_ == 0, 1.0, self.std_)
        scores = centered @ self.components_.T
        return pd.DataFrame(scores, index=yield_changes.index, columns=[f"PC{i+1}" for i in range(self.n_components)])

    def latest_decomposition(self, yield_history: pd.DataFrame) -> pd.DataFrame:
        hist = ensure_datetime_index(yield_history)
        latest_change = hist.diff().dropna().iloc[[-1]]
        scores = self.transform(latest_change)
        return scores

    def factor_loadings(self) -> pd.DataFrame:
        if self.components_ is None or self.maturities_ is None or self.explained_variance_ratio_ is None:
            raise RuntimeError("Call fit first.")
        out = pd.DataFrame(
            self.components_.T,
            index=self.maturities_,
            columns=[f"PC{i+1}" for i in range(self.n_components)],
        )
        out.index.name = "maturity_years"
        return out

    def factor_names(self) -> dict[str, str]:
        """Heuristic labels. Sign is arbitrary in PCA, so these are descriptive only."""
        return {"PC1": "level", "PC2": "slope", "PC3": "curvature"}


def pca_residual_richness(yield_history: pd.DataFrame, n_components: int = 3) -> pd.DataFrame:
    """Historical PCA residuals by tenor.

    Fit PCA on yield changes, reconstruct changes using first components, and
    return actual minus reconstructed change in basis points. Useful for detecting
    maturity sectors moving unusually relative to the curve.
    """
    model = YieldCurvePCA(n_components=n_components).fit(yield_history, use_changes=True)
    hist = ensure_datetime_index(yield_history)
    changes = hist.diff().dropna().astype(float)
    x = changes.values
    centered = x - model.mean_
    scores = centered @ model.components_.T
    reconstructed = scores @ model.components_ + model.mean_
    residual_pct = x - reconstructed
    return pd.DataFrame(residual_pct * 100.0, index=changes.index, columns=changes.columns)
