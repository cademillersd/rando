from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

import numpy as np
import pandas as pd

from rates_rv.analytics.curve import (
    FittedCurve,
    add_curve_residuals,
    historical_fitted_residuals,
    interpolate_history_to_maturity,
)
from rates_rv.utils import empirical_percentile, years_to_maturity


@dataclass
class RVConfig:
    curve_method: str = "pchip"
    z_window_days: int = 252
    rich_z_threshold: float = -1.5
    cheap_z_threshold: float = 1.5


class TreasuryRVEngine:
    def __init__(self, yield_history: pd.DataFrame, curve: FittedCurve, config: RVConfig | None = None):
        self.yield_history = yield_history
        self.curve = curve
        self.config = config or RVConfig()
        self.residual_history = historical_fitted_residuals(yield_history, method=self.config.curve_method)

    def score_bonds(self, bonds: pd.DataFrame, as_of: str | pd.Timestamp | None = None) -> pd.DataFrame:
        scored = add_curve_residuals(bonds, self.curve, as_of=as_of)
        z_scores: list[float | None] = []
        percentiles: list[float | None] = []
        for _, row in scored.iterrows():
            history = interpolate_history_to_maturity(self.residual_history, row["maturity_years"])
            mu = history.tail(self.config.z_window_days).mean()
            sigma = history.tail(self.config.z_window_days).std(ddof=1)
            z = None if sigma == 0 or np.isnan(sigma) else float((row["residual_bp"] - mu) / sigma)
            pct = empirical_percentile(history.tail(self.config.z_window_days), row["residual_bp"])
            z_scores.append(z)
            percentiles.append(pct)
        scored["residual_z"] = z_scores
        scored["percentile"] = percentiles
        scored["rv_label"] = np.select(
            [scored["residual_z"] <= self.config.rich_z_threshold, scored["residual_z"] >= self.config.cheap_z_threshold],
            ["RICH", "CHEAP"],
            default="NEUTRAL",
        )
        scored = add_nearest_otr(scored)
        return scored.sort_values("residual_z", key=lambda s: s.abs(), ascending=False)

    def score_ticket(self, ticket: pd.Series | dict, bonds: pd.DataFrame, as_of: str | pd.Timestamp | None = None) -> dict:
        ticket = pd.Series(ticket)
        scored = self.score_bonds(bonds, as_of=as_of)
        match = scored[scored["cusip"].astype(str).str.upper() == str(ticket["cusip"]).upper()]
        if match.empty:
            raise ValueError(f"Ticket CUSIP {ticket['cusip']} not found in bond universe")
        bond = match.iloc[0].to_dict()
        direction = "client_buy" if str(ticket["side"]).upper() == "BUY" else "client_sell"
        # If client buys, desk sells/shorts the bond; if the bond is rich, that is directionally favorable.
        if direction == "client_buy":
            desk_bias = "better_to_sell_rich_than_cheap"
        else:
            desk_bias = "better_to_buy_cheap_than_rich"
        return {"ticket": ticket.to_dict(), "bond_rv": bond, "desk_direction_context": desk_bias}

    def butterfly_scan(self, maturities: Iterable[tuple[float, float, float]] | None = None) -> pd.DataFrame:
        if maturities is None:
            maturities = [(2, 5, 10), (5, 10, 30), (2, 7, 10), (3, 5, 7), (7, 10, 30)]
        hist = self.yield_history.copy()
        if "date" in hist.columns:
            hist["date"] = pd.to_datetime(hist["date"])
            hist = hist.set_index("date")
        tenors = np.array([float(c) for c in hist.columns])
        rows = []
        for left, belly, right in maturities:
            left_s = _interp_history(hist, tenors, left)
            belly_s = _interp_history(hist, tenors, belly)
            right_s = _interp_history(hist, tenors, right)
            # Fly in bp: belly minus linear interpolation of wings.
            w = (belly - left) / (right - left)
            fly = 100.0 * (belly_s - ((1 - w) * left_s + w * right_s))
            latest = float(fly.iloc[-1])
            mu = fly.tail(self.config.z_window_days).mean()
            sd = fly.tail(self.config.z_window_days).std(ddof=1)
            z = None if sd == 0 or np.isnan(sd) else float((latest - mu) / sd)
            rows.append(
                {
                    "structure": f"{left:g}s{belly:g}s{right:g}s",
                    "left": left,
                    "belly": belly,
                    "right": right,
                    "fly_bp": latest,
                    "z_score": z,
                    "percentile": empirical_percentile(fly.tail(self.config.z_window_days), latest),
                    "label": "BELLY_CHEAP" if z is not None and z >= self.config.cheap_z_threshold else "BELLY_RICH" if z is not None and z <= self.config.rich_z_threshold else "NEUTRAL",
                }
            )
        return pd.DataFrame(rows).sort_values("z_score", key=lambda s: s.abs(), ascending=False)


def _interp_history(hist: pd.DataFrame, tenors: np.ndarray, target: float) -> pd.Series:
    values = []
    for _, row in hist.iterrows():
        values.append(np.interp(target, tenors, row.astype(float).values))
    return pd.Series(values, index=hist.index)


def add_nearest_otr(scored_bonds: pd.DataFrame) -> pd.DataFrame:
    out = scored_bonds.copy()
    if "is_otr" not in out.columns:
        out["nearest_otr_cusip"] = None
        out["spread_to_nearest_otr_bp"] = None
        return out
    otr = out[out["is_otr"].astype(bool)].copy()
    nearest_cusips = []
    spreads = []
    for _, row in out.iterrows():
        if otr.empty:
            nearest_cusips.append(None)
            spreads.append(None)
            continue
        idx = (otr["maturity_years"] - row["maturity_years"]).abs().idxmin()
        near = otr.loc[idx]
        nearest_cusips.append(near["cusip"])
        spreads.append(100.0 * (row["yield_pct"] - near["yield_pct"]))
    out["nearest_otr_cusip"] = nearest_cusips
    out["spread_to_nearest_otr_bp"] = spreads
    return out


def top_rich_cheap(scored: pd.DataFrame, n: int = 10) -> pd.DataFrame:
    cols = [
        "cusip",
        "description",
        "maturity_years",
        "yield_pct",
        "fitted_yield_pct",
        "residual_bp",
        "residual_z",
        "percentile",
        "rv_label",
        "nearest_otr_cusip",
        "spread_to_nearest_otr_bp",
    ]
    cols = [c for c in cols if c in scored.columns]
    return scored.sort_values("residual_z", key=lambda s: s.abs(), ascending=False)[cols].head(n)
