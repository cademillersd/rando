from __future__ import annotations

import pandas as pd


def simple_post_trade_attribution(
    ticket: pd.Series | dict,
    bond_before: pd.Series | dict,
    bond_after: pd.Series | dict,
    client_fill_yield_pct: float,
    hedge_pnl: float = 0.0,
) -> dict:
    """Very simple post-trade attribution for a Treasury ticket.

    This is intentionally lightweight. In production, use official PnL/risk from
    the bank system of record.
    """
    t = pd.Series(ticket)
    before = pd.Series(bond_before)
    after = pd.Series(bond_after)
    notional_mm = float(t["notional_mm"])
    dv01 = notional_mm * float(before["dv01_per_1mm"])
    desk_sign = 1 if str(t["side"]).upper() == "SELL" else -1  # desk long if client sells

    mid_yield_before = float(before["yield_pct"])
    market_move_bp = 100.0 * (float(after["yield_pct"]) - mid_yield_before)
    fill_edge_bp = 100.0 * (float(client_fill_yield_pct) - mid_yield_before) * (-desk_sign)

    pricing_edge = fill_edge_bp * dv01
    mark_to_market = -desk_sign * market_move_bp * dv01
    total = pricing_edge + mark_to_market + float(hedge_pnl)
    return {
        "pricing_edge_pnl": pricing_edge,
        "market_move_pnl": mark_to_market,
        "hedge_pnl": hedge_pnl,
        "total_estimated_pnl": total,
        "market_move_bp": market_move_bp,
        "fill_edge_bp": fill_edge_bp,
    }
