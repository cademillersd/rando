from __future__ import annotations

from datetime import date, datetime
from typing import Literal

from pydantic import BaseModel, Field, field_validator


class TreasuryBond(BaseModel):
    cusip: str
    description: str
    maturity_date: date
    coupon_pct: float
    yield_pct: float
    price: float
    dv01_per_1mm: float = Field(description="Dollar DV01 per $1mm notional")
    issue_size_mm: float | None = None
    is_otr: bool = False
    sector: str | None = None
    bid_yield_pct: float | None = None
    ask_yield_pct: float | None = None
    liquidity_score: float | None = None

    @field_validator("cusip")
    @classmethod
    def normalize_cusip(cls, value: str) -> str:
        return value.strip().upper()


class Ticket(BaseModel):
    ticket_id: str
    timestamp: datetime
    side: Literal["BUY", "SELL"]
    cusip: str
    notional_mm: float

    @field_validator("cusip")
    @classmethod
    def normalize_cusip(cls, value: str) -> str:
        return value.strip().upper()

    @field_validator("side")
    @classmethod
    def normalize_side(cls, value: str) -> str:
        return value.strip().upper()


class HedgeInstrument(BaseModel):
    symbol: str
    description: str
    dv01_per_contract: float
    maturity_bucket: float | None = None
    contract_size: float | None = None
    price: float | None = None


class RVSignal(BaseModel):
    cusip: str
    description: str
    maturity_years: float
    yield_pct: float
    fitted_yield_pct: float
    residual_bp: float
    residual_z: float | None
    percentile: float | None
    is_rich: bool
    is_cheap: bool
    nearest_otr_cusip: str | None = None
    spread_to_nearest_otr_bp: float | None = None
