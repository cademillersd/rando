from __future__ import annotations

import os
from pathlib import Path

from rates_rv.integrations.base import MarketDataClient
from rates_rv.integrations.csv_client import CSVMarketDataClient
from rates_rv.integrations.mock_client import MockRiskValClient
from rates_rv.integrations.riskval import RiskValRESTClient, RiskValRVPythonClient


def make_client(backend: str | None = None, data_dir: str | Path | None = None) -> MarketDataClient:
    backend = (backend or os.getenv("RISKVAL_BACKEND", "csv")).lower()
    if backend == "csv":
        return CSVMarketDataClient(data_dir or os.getenv("RATES_RV_DATA_DIR", "data/sample"))
    if backend == "mock":
        return MockRiskValClient()
    if backend == "rvpython":
        return RiskValRVPythonClient.from_env()
    if backend == "rest":
        return RiskValRESTClient.from_env()
    raise ValueError(f"Unknown backend {backend!r}. Use csv, mock, rvpython, or rest.")
