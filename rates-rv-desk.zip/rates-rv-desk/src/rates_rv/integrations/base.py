from __future__ import annotations

from abc import ABC, abstractmethod

import pandas as pd


class MarketDataClient(ABC):
    """Data access boundary.

    Keep vendor/proprietary data access here. Analytics code should depend only on
    normalized pandas DataFrames returned by this interface.
    """

    @abstractmethod
    def get_yield_history(self) -> pd.DataFrame:
        """Return historical Treasury yields with date + maturity columns."""

    @abstractmethod
    def get_bond_universe(self) -> pd.DataFrame:
        """Return current Treasury bond universe."""

    def get_tickets(self) -> pd.DataFrame:
        """Return open/monitorable tickets. Optional for demo."""
        return pd.DataFrame()

    def get_futures_analytics(self) -> pd.DataFrame:
        """Return futures hedge analytics. Optional for demo."""
        return pd.DataFrame()
