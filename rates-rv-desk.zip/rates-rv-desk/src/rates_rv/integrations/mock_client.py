from __future__ import annotations

from datetime import datetime, timedelta

import numpy as np
import pandas as pd

from rates_rv.integrations.base import MarketDataClient


class MockRiskValClient(MarketDataClient):
    """Deterministic sample data for local development.

    This lets you build the desk analytics before you get RiskVal/ION permissions.
    """

    def __init__(self, seed: int = 7, n_days: int = 756):
        self.seed = seed
        self.n_days = n_days

    def get_yield_history(self) -> pd.DataFrame:
        rng = np.random.default_rng(self.seed)
        dates = pd.bdate_range(end=pd.Timestamp.today().normalize(), periods=self.n_days)
        tenors = np.array([0.25, 0.5, 1, 2, 3, 5, 7, 10, 20, 30], dtype=float)

        level = 4.20 + np.cumsum(rng.normal(0, 0.015, len(dates)))
        slope = -0.65 + np.cumsum(rng.normal(0, 0.006, len(dates)))
        curvature = 0.25 + np.cumsum(rng.normal(0, 0.004, len(dates)))

        x = np.log1p(tenors) / np.log1p(30)
        curves = []
        for l, s, c in zip(level, slope, curvature):
            y = l + s * (x - 0.55) + c * (1 - 4 * (x - 0.5) ** 2)
            y += rng.normal(0, 0.015, len(tenors))
            curves.append(y)
        out = pd.DataFrame(curves, columns=[str(t) for t in tenors])
        out.insert(0, "date", dates)
        return out

    def get_bond_universe(self) -> pd.DataFrame:
        rng = np.random.default_rng(self.seed + 1)
        as_of = pd.Timestamp.today().normalize()
        maturities = np.array([0.35, 0.7, 1.0, 1.4, 2.0, 2.6, 3.1, 4.0, 5.0, 6.5, 7.0, 8.5, 10.0, 12.0, 20.0, 30.0])
        latest = self.get_yield_history().drop(columns=["date"]).iloc[-1]
        tenors = np.array([float(c) for c in latest.index])
        base_yields = np.interp(maturities, tenors, latest.values)
        residuals_bp = rng.normal(0, 2.0, len(maturities))
        # Make a few visible signals.
        residuals_bp[4] = -5.0
        residuals_bp[10] = 6.2
        residuals_bp[12] = -4.8

        rows = []
        for i, (mat, y, res_bp) in enumerate(zip(maturities, base_yields, residuals_bp)):
            maturity_date = as_of + pd.Timedelta(days=int(mat * 365.25))
            sector = min([2, 3, 5, 7, 10, 20, 30], key=lambda z: abs(z - mat))
            is_otr = mat in {2.0, 3.1, 5.0, 7.0, 10.0, 20.0, 30.0}
            coupon = round(max(y, 0.125) * 8) / 8
            rows.append(
                {
                    "cusip": f"91282C{i:03d}",
                    "description": f"UST {coupon:.3f}% {maturity_date.strftime('%b-%Y')}",
                    "maturity_date": maturity_date.date().isoformat(),
                    "coupon_pct": coupon,
                    "yield_pct": round(float(y + res_bp / 100.0), 4),
                    "price": round(100 + rng.normal(0, 1.5), 4),
                    "dv01_per_1mm": round(92 * mat / (1 + 0.02 * mat), 2),
                    "issue_size_mm": float(rng.integers(35_000, 75_000)),
                    "is_otr": is_otr,
                    "sector": f"{sector}Y",
                    "bid_yield_pct": round(float(y + res_bp / 100.0 - 0.005), 4),
                    "ask_yield_pct": round(float(y + res_bp / 100.0 + 0.005), 4),
                    "liquidity_score": round(float(rng.uniform(0.3, 1.0)), 3),
                }
            )
        return pd.DataFrame(rows)

    def get_tickets(self) -> pd.DataFrame:
        bonds = self.get_bond_universe()
        now = datetime.now().replace(microsecond=0)
        return pd.DataFrame(
            [
                {
                    "ticket_id": "TCKT-001",
                    "timestamp": now.isoformat(),
                    "side": "BUY",
                    "cusip": bonds.loc[10, "cusip"],
                    "notional_mm": 50,
                },
                {
                    "ticket_id": "TCKT-002",
                    "timestamp": (now - timedelta(minutes=6)).isoformat(),
                    "side": "SELL",
                    "cusip": bonds.loc[12, "cusip"],
                    "notional_mm": 35,
                },
            ]
        )

    def get_futures_analytics(self) -> pd.DataFrame:
        return pd.DataFrame(
            [
                {"symbol": "TU", "description": "2Y Treasury Future", "dv01_per_contract": 39.0, "maturity_bucket": 2},
                {"symbol": "FV", "description": "5Y Treasury Future", "dv01_per_contract": 48.0, "maturity_bucket": 5},
                {"symbol": "TY", "description": "10Y Treasury Future", "dv01_per_contract": 72.0, "maturity_bucket": 10},
                {"symbol": "US", "description": "Classic Bond Future", "dv01_per_contract": 138.0, "maturity_bucket": 20},
                {"symbol": "WN", "description": "Ultra Bond Future", "dv01_per_contract": 205.0, "maturity_bucket": 30},
            ]
        )
