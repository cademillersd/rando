from __future__ import annotations

import os
from typing import Any

import pandas as pd
import requests


class IONConfigError(RuntimeError):
    pass


class IONRESTClient:
    """Generic adapter for an internal ION/order-book wrapper.

    Actual ION access is almost always permissioned and bank-specific. Use this
    only if technology/compliance gives you an approved endpoint. The analytics
    code does not require this adapter.
    """

    def __init__(self, base_url: str, token: str | None = None, timeout_seconds: float = 10.0):
        self.base_url = base_url.rstrip("/")
        self.token = token
        self.timeout_seconds = timeout_seconds

    @classmethod
    def from_env(cls) -> "IONRESTClient":
        base_url = os.getenv("ION_REST_BASE_URL")
        if not base_url:
            raise IONConfigError("Set ION_REST_BASE_URL for ION REST adapter.")
        return cls(
            base_url=base_url,
            token=os.getenv("ION_REST_TOKEN"),
            timeout_seconds=float(os.getenv("ION_REST_TIMEOUT_SECONDS", "10")),
        )

    def _get(self, endpoint: str, params: dict[str, Any] | None = None) -> pd.DataFrame:
        headers = {}
        if self.token:
            headers["Authorization"] = f"Bearer {self.token}"
        response = requests.get(
            f"{self.base_url}/{endpoint.lstrip('/')}",
            headers=headers,
            params=params,
            timeout=self.timeout_seconds,
        )
        response.raise_for_status()
        payload = response.json()
        if isinstance(payload, dict):
            for key in ("data", "rows", "orders", "tickets"):
                if key in payload:
                    return pd.DataFrame(payload[key])
            return pd.DataFrame([payload])
        return pd.DataFrame(payload)

    def get_order_book(self, cusip: str) -> pd.DataFrame:
        return self._get("order-book", params={"cusip": cusip})

    def get_ticket_notifications(self) -> pd.DataFrame:
        return self._get("ticket-notifications", params={"asset_class": "UST"})
