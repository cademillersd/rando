from __future__ import annotations

from pathlib import Path

import pandas as pd

from rates_rv.integrations.base import MarketDataClient


class CSVMarketDataClient(MarketDataClient):
    def __init__(self, data_dir: str | Path):
        self.data_dir = Path(data_dir)

    def _read(self, filename: str) -> pd.DataFrame:
        path = self.data_dir / filename
        if not path.exists():
            raise FileNotFoundError(f"Missing {path}. Run scripts/generate_sample_data.py first or provide your own CSV.")
        return pd.read_csv(path)

    def get_yield_history(self) -> pd.DataFrame:
        return self._read("yield_history.csv")

    def get_bond_universe(self) -> pd.DataFrame:
        return self._read("bonds.csv")

    def get_tickets(self) -> pd.DataFrame:
        path = self.data_dir / "tickets.csv"
        return pd.read_csv(path) if path.exists() else pd.DataFrame()

    def get_futures_analytics(self) -> pd.DataFrame:
        path = self.data_dir / "futures.csv"
        return pd.read_csv(path) if path.exists() else pd.DataFrame()
