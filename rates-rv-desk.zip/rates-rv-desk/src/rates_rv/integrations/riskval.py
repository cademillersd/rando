from __future__ import annotations

import importlib
import os
from pathlib import Path
from typing import Any, Callable

import pandas as pd
import requests
import yaml

from rates_rv.integrations.base import MarketDataClient


class RiskValConfigError(RuntimeError):
    pass


def _to_dataframe(obj: Any) -> pd.DataFrame:
    if isinstance(obj, pd.DataFrame):
        return obj.copy()
    if isinstance(obj, list):
        return pd.DataFrame(obj)
    if isinstance(obj, dict):
        # Common patterns: {"data": [...]}, {"rows": [...]}
        for key in ("data", "rows", "result"):
            if key in obj:
                return _to_dataframe(obj[key])
        return pd.DataFrame([obj])
    raise TypeError(f"Cannot convert {type(obj)!r} to pandas DataFrame")


class RiskValRVPythonClient(MarketDataClient):
    """Adapter for RiskVal RVPython.

    Public docs confirm RVPython exists, but not desk-specific function names.
    This adapter reads the function map from YAML and calls methods dynamically.
    That keeps proprietary RiskVal details out of analytics code.
    """

    def __init__(self, module_name: str, mapping_path: str | Path):
        self.module_name = module_name
        self.mapping_path = Path(mapping_path)
        if not self.mapping_path.exists():
            raise RiskValConfigError(f"Missing mapping file: {self.mapping_path}")
        self.mapping = yaml.safe_load(self.mapping_path.read_text()) or {}
        self.functions = self.mapping.get("functions", {})
        self.arguments = self.mapping.get("arguments", {})
        try:
            self.rv = importlib.import_module(module_name)
        except ModuleNotFoundError as exc:
            raise RiskValConfigError(
                f"Could not import RVPython module {module_name!r}. "
                "Set RISKVAL_RVPYTHON_MODULE to your desk's installed package name."
            ) from exc

    @classmethod
    def from_env(cls) -> "RiskValRVPythonClient":
        return cls(
            module_name=os.getenv("RISKVAL_RVPYTHON_MODULE", "rvpython"),
            mapping_path=os.getenv("RISKVAL_MAPPING", "config/riskval_mapping.local.yaml"),
        )

    def _call(self, logical_name: str) -> pd.DataFrame:
        function_name = self.functions.get(logical_name)
        if not function_name:
            raise RiskValConfigError(f"No function mapping configured for {logical_name!r}.")
        fn: Callable[..., Any] | None = getattr(self.rv, function_name, None)
        if fn is None:
            raise RiskValConfigError(
                f"RVPython module {self.module_name!r} has no function {function_name!r}. "
                "Update config/riskval_mapping.local.yaml."
            )
        kwargs = self.arguments.get(logical_name, {}) or {}
        return _to_dataframe(fn(**kwargs))

    def get_yield_history(self) -> pd.DataFrame:
        return self._call("get_yield_history")

    def get_bond_universe(self) -> pd.DataFrame:
        return self._call("get_bond_universe")

    def get_tickets(self) -> pd.DataFrame:
        return self._call("get_tickets")

    def get_futures_analytics(self) -> pd.DataFrame:
        return self._call("get_futures_analytics")


class RiskValRESTClient(MarketDataClient):
    """Generic REST adapter for an internal RiskVal/data wrapper.

    Many banks do not expose vendor APIs directly to interns. If technology gives
    you an internal service, map these endpoints to it.
    """

    def __init__(self, base_url: str, token: str | None = None, timeout_seconds: float = 20.0):
        self.base_url = base_url.rstrip("/")
        self.token = token
        self.timeout_seconds = timeout_seconds

    @classmethod
    def from_env(cls) -> "RiskValRESTClient":
        base_url = os.getenv("RISKVAL_REST_BASE_URL")
        if not base_url:
            raise RiskValConfigError("Set RISKVAL_REST_BASE_URL for REST backend.")
        timeout = float(os.getenv("RISKVAL_REST_TIMEOUT_SECONDS", "20"))
        return cls(base_url=base_url, token=os.getenv("RISKVAL_REST_TOKEN"), timeout_seconds=timeout)

    def _get(self, endpoint: str, params: dict[str, Any] | None = None) -> pd.DataFrame:
        headers = {}
        if self.token:
            headers["Authorization"] = f"Bearer {self.token}"
        url = f"{self.base_url}/{endpoint.lstrip('/')}"
        response = requests.get(url, params=params, headers=headers, timeout=self.timeout_seconds)
        response.raise_for_status()
        return _to_dataframe(response.json())

    def get_yield_history(self) -> pd.DataFrame:
        return self._get("yield-history", params={"curve": "UST"})

    def get_bond_universe(self) -> pd.DataFrame:
        return self._get("treasury-universe")

    def get_tickets(self) -> pd.DataFrame:
        return self._get("tickets", params={"desk": "UST", "status": "OPEN"})

    def get_futures_analytics(self) -> pd.DataFrame:
        return self._get("futures-analytics", params={"currency": "USD"})
