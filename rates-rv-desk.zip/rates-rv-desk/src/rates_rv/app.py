from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd
import plotly.express as px
import streamlit as st

from rates_rv.analytics.curve import latest_curve_from_history
from rates_rv.analytics.pca import YieldCurvePCA
from rates_rv.analytics.rv import RVConfig, TreasuryRVEngine, top_rich_cheap
from rates_rv.analytics.ticket import enrich_ticket
from rates_rv.analytics.pretrade import execution_checklist
from rates_rv.integrations.factory import make_client


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("--backend", default=None)
    parser.add_argument("--data-dir", default=None)
    args, _ = parser.parse_known_args()
    return args


@st.cache_data(ttl=60)
def load_data(backend: str | None, data_dir: str | None):
    client = make_client(backend=backend, data_dir=data_dir)
    return client.get_yield_history(), client.get_bond_universe(), client.get_tickets(), client.get_futures_analytics()


def main() -> None:
    args = parse_args()
    st.set_page_config(page_title="Rates RV Desk Assistant", layout="wide")
    st.title("Rates RV Desk Assistant")
    st.caption("Treasury PCA, relative value, richness/cheapness, and hedge context")

    with st.sidebar:
        st.header("Configuration")
        backend = st.selectbox("Backend", [args.backend or "csv", "csv", "mock", "rvpython", "rest"], index=0)
        data_dir = st.text_input("CSV data dir", args.data_dir or "data/sample")
        z_threshold = st.slider("Rich/cheap z threshold", 0.5, 3.0, 1.5, 0.1)
        curve_method = st.selectbox("Curve fit", ["pchip", "cubic", "poly"], index=0)

    yield_history, bonds, tickets, futures = load_data(backend, data_dir)
    curve = latest_curve_from_history(yield_history, method=curve_method)
    rv_engine = TreasuryRVEngine(
        yield_history,
        curve,
        RVConfig(curve_method=curve_method, rich_z_threshold=-z_threshold, cheap_z_threshold=z_threshold),
    )
    scored = rv_engine.score_bonds(bonds)
    pca = YieldCurvePCA(n_components=3).fit(yield_history)

    c1, c2, c3 = st.columns(3)
    with c1:
        st.metric("Bonds scored", len(scored))
    with c2:
        st.metric("Rich bonds", int((scored["rv_label"] == "RICH").sum()))
    with c3:
        st.metric("Cheap bonds", int((scored["rv_label"] == "CHEAP").sum()))

    st.subheader("Top Rich/Cheap Bonds")
    st.dataframe(top_rich_cheap(scored, n=20), use_container_width=True)

    st.subheader("Curve Residuals")
    fig = px.scatter(
        scored,
        x="maturity_years",
        y="residual_bp",
        color="rv_label",
        hover_data=["cusip", "description", "yield_pct", "fitted_yield_pct", "residual_z", "nearest_otr_cusip"],
        title="Yield minus fitted curve, bp",
    )
    st.plotly_chart(fig, use_container_width=True)

    st.subheader("PCA Factor Loadings")
    loadings = pca.factor_loadings().reset_index()
    long_loadings = loadings.melt(id_vars="maturity_years", var_name="factor", value_name="loading")
    fig2 = px.line(long_loadings, x="maturity_years", y="loading", color="factor", markers=True)
    st.plotly_chart(fig2, use_container_width=True)
    evr = pd.DataFrame(
        {"factor": ["PC1", "PC2", "PC3"], "explained_variance_pct": pca.explained_variance_ratio_ * 100}
    )
    st.dataframe(evr, use_container_width=True)

    st.subheader("Butterfly Scanner")
    st.dataframe(rv_engine.butterfly_scan(), use_container_width=True)

    st.subheader("Ticket Enrichment")
    if tickets.empty:
        st.info("No tickets available for this backend.")
    else:
        ticket_ids = tickets["ticket_id"].astype(str).tolist()
        selected = st.selectbox("Ticket", ticket_ids)
        ticket = tickets[tickets["ticket_id"].astype(str) == selected].iloc[0]
        card = enrich_ticket(ticket, bonds, rv_engine, futures)
        st.write(card["decision_note"])
        st.json({k: v for k, v in card["bond"].items() if k not in {"index"}})
        st.write("Pre-trade checklist")
        for item in execution_checklist(card):
            st.write(f"- {item}")
        st.write("Future hedge candidates")
        st.dataframe(card["future_hedges"], use_container_width=True)
        st.write("Approximate key-rate exposure fallback")
        st.dataframe(card["key_rate_exposure"], use_container_width=True)


if __name__ == "__main__":
    main()
